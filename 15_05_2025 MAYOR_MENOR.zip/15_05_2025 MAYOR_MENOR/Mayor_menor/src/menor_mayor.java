import java.util.Scanner;

public class menor_mayor {

    public void cargarValores() {
        Scanner teclado = new Scanner(System.in);

        System.out.println("Ingrese el primer valor:");
        int valor1 = teclado.nextInt();

        System.out.println("Ingrese el segundo valor:");
        int valor2 = teclado.nextInt();

        System.out.println("Ingrese el tercer valor:");
        int valor3 = teclado.nextInt();

        int mayor = calcularNumeroMayor(valor1, valor2, valor3);
        int menor = calcularNumeroMenor(valor1, valor2, valor3);

        System.out.println("El número mayor es: " + mayor);
        System.out.println("El número menor es: " + menor);

        teclado.close();
    }

    public int calcularNumeroMayor(int v1, int v2, int v3) {
        if (v1 >= v2 && v1 >= v3) {
            return v1;
        } else if (v2 >= v3) {
            return v2;
        } else {
            return v3;
        }
    }

    public int calcularNumeroMenor(int v1, int v2, int v3) {
        if (v1 <= v2 && v1 <= v3) {
            return v1;
        } else if (v2 <= v3) {
            return v2;
        } else {
            return v3;
        }
    }

    public static void main(String[] args) {
        menor_mayor programa = new menor_mayor();
        programa.cargarValores();
    }
}

