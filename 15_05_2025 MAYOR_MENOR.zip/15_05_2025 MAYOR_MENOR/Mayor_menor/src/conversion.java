import java.util.Scanner;

public class conversion {
    public static double cAF(double c) { return (c * 9 / 5) + 32; }
    public static double fAC(double f) { return (f - 32) * 5 / 9; }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int repetir;
        do {
            System.out.println("1. Celsius a Fahrenheit");
            System.out.println("2. Fahrenheit a Celsius");
            System.out.print("Opción: ");
            int opcion = sc.nextInt();
            if (opcion == 1) {
                System.out.print("Inngrese °C: ");
                double c = sc.nextDouble();
                System.out.println("Resultado: " + cAF(c) + " °F");
            } else if (opcion == 2) {
                System.out.print("Ingrese °F: ");
                double f = sc.nextDouble();
                System.out.println("Resultado: " + fAC(f) + " °C");
            } else {
                System.out.println("Opción inválida.");
            }
            System.out.print("¿Otra conversión? (1 = sí, 2 = no): ");
            repetir = sc.nextInt();
        } while (repetir == 1);
        sc.close();
    }
}
