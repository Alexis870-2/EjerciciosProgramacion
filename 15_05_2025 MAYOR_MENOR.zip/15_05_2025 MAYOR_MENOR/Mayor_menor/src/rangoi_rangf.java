import java.util.Scanner;

public class rangoi_rangf {

    public static int calcularSumatoria(int inicio, int fin) {
        int suma = 0;
        for (int i = inicio; i <= fin; i++) {
            suma += i;
        }
        return suma;
    }

    public static void imprimirNumeros(int inicio, int fin) {
        System.out.print("Números sumados: ");
        for (int i = inicio; i <= fin; i++) {
            System.out.print(i);
            if (i < fin) System.out.print(", ");
        }
        System.out.println();
    }

    public static double calcularPromedio(int suma, int cantidad) {
        return (double) suma / cantidad;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int repetir;

        do {
            System.out.print("Ingrese el número inicial del rango: ");
            int inicio = sc.nextInt();

            System.out.print("Ingrese el número final del rango: ");
            int fin = sc.nextInt();

            if (fin < inicio) {
                System.out.println("El número final debe ser mayor o igual al inicial.");
            } else {
                imprimirNumeros(inicio, fin);
                int suma = calcularSumatoria(inicio, fin);
                int cantidad = fin - inicio + 1;
                double promedio = calcularPromedio(suma, cantidad);

                System.out.println("Cantidad de números: " + cantidad);
                System.out.println("Sumatoria: " + suma);
                System.out.println("Promedio: " + promedio);
            }

            System.out.print("¿Desea realizar otra operación? (1 = sí, 2 = no): ");
            repetir = sc.nextInt();

        } while (repetir == 1);

        sc.close();
    }
}
