import java.security.PublicKey;

public class PERSONAJE {
String apellido;
String cedula;
String nombre;
int edad;


public PERSONAJE(){

}

public PERSONAJE  (String apellido_,String cedeula_,String nombre_,int edad_){
apellido=apellido_;
nombre=nombre_;
cedula=cedeula_;
edad=edad_;




}



public PERSONAJE(String cedeula_){
cedula=cedeula_;

}

public void  INICIALIZARVALORESP(String apellido_,String cedeula_,String nombre_,int edad_){

apellido=apellido_;
nombre=nombre_;
cedula=cedeula_;
edad=edad_;

}




public static void main(String[] args) {
    
    PERSONAJE persona= new PERSONAJE();

    persona.apellido="vera";
      persona.nombre="ana";
        persona.cedula="1848384381";
          persona.edad=134;

  PERSONAJE persona2= new PERSONAJE("serrano", "1802414231", "JUAN", 30);

PERSONAJE persona3= new PERSONAJE("14030420324");
PERSONAJE persona4= new PERSONAJE();
persona4.INICIALIZARVALORESP("x", "2", "sss", 0);















}












}
