import java.rmi.StubNotFoundException;
import java.security.PublicKey;
import java.util.Scanner;
import java.util.concurrent.Flow.Subscriber;

public class VEHIVULO {
String marca;
String modelo;
int año;
static double precio;
String color;
double promedio=0;


//ing




public double PROMEDIOVENTA(double v1,double v2,double v3){

    double promedio =(v1+v2+v3);
    return promedio;
}



//public double GANACNCIA15(double v1,double v2,double v3){

    //double ganaciav1=v1*0.15;
     //double ganaciav2=v2*0.15;
    //  double ganaciav3=v3*0.15;


  //  return ganaciav1+ganaciav2+ganaciav3;
//}


public double GANACNCIA15(double PORCENTAJE,double v1,double v2,double v3){

    double ganaciav1=v1*PORCENTAJE;
     double ganaciav2=v2*PORCENTAJE;
      double ganaciav3=v3*PORCENTAJE;


    return ganaciav1+ganaciav2+ganaciav3;
}






//hasta aqui




public void IMPRIMIR(){
    System.out.println("=============================");
    System.out.println("informacion del vehiculo");
    System.out.println("=============================");
    System.out.println("marca "+marca);
     System.out.println("MODELO"+modelo);
      System.out.println("AÑO "+año);
       System.out.println("COLOR "+color);
        System.out.println("PRESIO "+precio);
}

public double ganancia(double precio1){
    double inte;
    Scanner teclado=new Scanner (System.in);
    
System.out.println("ingrese cuando porciento queire ganar ");
inte=teclado.nextInt();
inte =inte/100;
double ganancia=precio*inte;
System.out.println(ganancia);
    return precio1;
}


public void Sumarvehiculos(){

 
System.out.println(promedio);

}

public void PROMEDIO(){
    double promedio1=promedio/3;
    System.out.println("el promedio es"+promedio1);

}


public void ACTUALIZAR(String marca_,String modelo_,int año_,String color_,double precio_ ){
marca=marca_;
modelo=modelo_;
año=año_;
color=color_;
precio=precio_;


}
public static void main(String[] args) {


     Scanner teclado=new Scanner(System.in);
    VEHIVULO vehiculo_1=new VEHIVULO();
    vehiculo_1.marca="kia";
    vehiculo_1.modelo="kia serato";
    vehiculo_1.año=2016;
    vehiculo_1.color="negro";
    vehiculo_1.precio=12000;
    vehiculo_1.IMPRIMIR();
vehiculo_1.ganancia(precio);




       VEHIVULO vehiculo_2=new VEHIVULO();

vehiculo_2.ACTUALIZAR("SUSUKI", "susuki famy", 2020, "ROJO", 19000);
vehiculo_2.IMPRIMIR();
vehiculo_2.ganancia(precio);

       VEHIVULO vehiculo_3=new VEHIVULO();
       

vehiculo_3.ACTUALIZAR("TOYOTA", "COROLLA", 2019, "GRIS", 17500);
vehiculo_3.IMPRIMIR();
vehiculo_3.ganancia(precio);



double promedio= vehiculo_1.PROMEDIOVENTA(vehiculo_1.precio, vehiculo_2.precio, vehiculo_3.precio);

System.out.println("EL PROMEDIO ES  DE 15"+ promedio);

double GANANCIAT=vehiculo_1.GANACNCIA15(0.15, vehiculo_1.precio, vehiculo_2.precio, vehiculo_3.precio);

System.out.println("la ganancia es"+ GANANCIAT);
System.out.println("INGRESE EL PORCENTAJE DE GANACIA");

double porcentajeGanancia= teclado.nextDouble();
GANANCIAT=vehiculo_1.GANACNCIA15(porcentajeGanancia, vehiculo_1.precio, vehiculo_2.precio, vehiculo_3.precio);
System.out.println("LA GANANCIA DE "+porcentajeGanancia+" es: "+GANANCIAT);



}














}
