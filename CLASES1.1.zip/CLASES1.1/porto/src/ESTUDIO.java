import java.util.Scanner;

public class ESTUDIO {
    //ATRIBUTOS NOS AYUDA A DIFINIR CARCTERISTICAS
    String materia="Fp";
    int TIEMPO=60;

    
    public void IMPRIMIRINFO(){


        System.out.println("materia = "+ materia+ "el tiempo de estudip"+TIEMPO+" en minutps");
    }
    
    
    
    public void ACTUALIZARINFORMACION(String _materia,int _TIEMPO){

        materia=_materia;
        TIEMPO=_TIEMPO;

    }
    
    public void INGRESARATRIBUTOS(){

Scanner sc=new Scanner(System.in);
System.out.println("ingres el nombre");
materia=sc.next();
System.out.println("ingres el tiempo");
TIEMPO=sc.nextInt();

    }




    
    
    
    
    public static void main(String[] args) throws Exception {
        ESTUDIO estudio= new ESTUDIO();
        estudio.IMPRIMIRINFO();
        estudio.materia="FUNDAMENTOS DE PROGRA0";
        estudio.TIEMPO=90;
estudio.IMPRIMIRINFO();
estudio.ACTUALIZARINFORMACION("FISICA", 30);
estudio.IMPRIMIRINFO();
estudio.INGRESARATRIBUTOS();
estudio.IMPRIMIRINFO();

    }
}
