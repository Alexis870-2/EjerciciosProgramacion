import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Random;

public class TanqueContraNaveGame extends JFrame {
    private int tamCelda = 40;
    private int enemigoX, enemigoY;
    private int tiros = 0, puntos = 0, nivel = 1, vidas = 3;

    private JTextField inputAngulo;
    private JLabel lblPuntos, lblNivel, lblVidas;
    private AreaJuego areaJuego;
    private Random random = new Random();
    private Timer animacionDisparo;

    public TanqueContraNaveGame() {
        setTitle("Tanque contra Nave");
        setSize(800, 600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JPanel panelControles = new JPanel();
        panelControles.setLayout(new BoxLayout(panelControles, BoxLayout.Y_AXIS));
        panelControles.setBackground(Color.LIGHT_GRAY);
        panelControles.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JLabel lblAngulo = new JLabel("Ángulo de disparo:");
        inputAngulo = new JTextField(5);
        JButton btnDisparar = new JButton("DISPARAR");

        lblPuntos = new JLabel("PUNTOS: 0");
        lblNivel = new JLabel("NIVEL: 1");
        lblVidas = new JLabel("VIDAS: 3");

        panelControles.add(lblAngulo);
        panelControles.add(inputAngulo);
        panelControles.add(Box.createRigidArea(new Dimension(0, 10)));
        panelControles.add(btnDisparar);
        panelControles.add(Box.createRigidArea(new Dimension(0, 20)));
        panelControles.add(lblPuntos);
        panelControles.add(lblNivel);
        panelControles.add(lblVidas);
        add(panelControles, BorderLayout.WEST);

        areaJuego = new AreaJuego();
        areaJuego.setBackground(Color.WHITE);
        add(areaJuego, BorderLayout.CENTER);

        btnDisparar.addActionListener(e -> disparar());

        iniciarNivel();
        setLocationRelativeTo(null);
    }

    private void disparar() {
        try {
            int angulo = Integer.parseInt(inputAngulo.getText());
            if (angulo < 0 || angulo > 90) {
                JOptionPane.showMessageDialog(this, "El ángulo debe estar entre 0 y 90.");
                return;
            }

            tiros++;
            double rad = Math.toRadians(angulo);
            int x0 = tamCelda * 2;
            int y0 = areaJuego.getHeight() - tamCelda * 2;

            int[] paso = {0};
            int velocidad = 10;

            if (animacionDisparo != null && animacionDisparo.isRunning()) {
                animacionDisparo.stop();
            }

            animacionDisparo = new Timer(20, null);
            animacionDisparo.addActionListener(e -> {
                int dx = (int)(Math.cos(rad) * paso[0] / 10 * velocidad);
                int dy = (int)(Math.sin(rad) * paso[0] / 10 * velocidad);
                int x1 = x0 + dx;
                int y1 = y0 - dy;

                areaJuego.setDisparo(x0, y0, x1, y1);

                int celdaX = x1 / tamCelda;
                int celdaY = (areaJuego.getHeight() - y1) / tamCelda;

                if (celdaX == enemigoX && celdaY == enemigoY) {
                    animacionDisparo.stop();
                    areaJuego.borrarDisparo();
                    puntos += 100;
                    actualizarEtiquetas();
                    if (puntos >= nivel * 300) {
                        nivel++;
                        JOptionPane.showMessageDialog(this, "¡Nivel superado!");
                        iniciarNivel();
                    } else {
                        moverEnemigo();
                    }
                    tiros = 0;
                } else if (x1 > getWidth() || y1 < 0 || x1 < 0) {
                    animacionDisparo.stop();
                    areaJuego.borrarDisparo();
                    vidas--;
                    actualizarEtiquetas();
                    if (vidas <= 0) {
                        JOptionPane.showMessageDialog(this, "Game Over\nPuntaje: " + puntos);
                        System.exit(0);
                    } else {
                        if (tiros >= 3) {
                            moverEnemigo();
                        }
                    }
                }

                paso[0] += 5;
            });
            animacionDisparo.start();

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Ingresa un número válido.");
        }
    }

    private void actualizarEtiquetas() {
        lblPuntos.setText("PUNTOS: " + puntos);
        lblNivel.setText("NIVEL: " + nivel);
        lblVidas.setText("VIDAS: " + vidas);
    }

    private void iniciarNivel() {
        enemigoX = obtenerX();
        enemigoY = obtenerY();
        areaJuego.setEnemigo(enemigoX, enemigoY);
        tiros = 0;
    }

    private void moverEnemigo() {
        enemigoX = obtenerX();
        enemigoY = obtenerY();
        areaJuego.setEnemigo(enemigoX, enemigoY);
    }

    private int obtenerX() {
        int cols = getWidth() / tamCelda - 2;
        return 3 + random.nextInt(cols - 4);
    }

    private int obtenerY() {
        int rows = getHeight() / tamCelda - 4;
        return 3 + random.nextInt(rows - 4);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new TanqueContraNaveGame().setVisible(true));
    }

    class AreaJuego extends JPanel {
        private int x0, y0, x1, y1;
        private boolean dibujar = false;
        private int enemigoCeldaX, enemigoCeldaY;

        public void setDisparo(int x0, int y0, int x1, int y1) {
            this.x0 = x0;
            this.y0 = y0;
            this.x1 = x1;
            this.y1 = y1;
            dibujar = true;
            repaint();
        }

        public void borrarDisparo() {
            dibujar = false;
            repaint();
        }

        public void setEnemigo(int cx, int cy) {
            enemigoCeldaX = cx;
            enemigoCeldaY = cy;
            repaint();
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            // Dibujar cuadrícula
            g.setColor(Color.GRAY);
            for (int x = 0; x < getWidth(); x += tamCelda) {
                g.drawLine(x, 0, x, getHeight());
            }
            for (int y = 0; y < getHeight(); y += tamCelda) {
                g.drawLine(0, y, getWidth(), y);
            }

            // Tanque
            int tanqueX = tamCelda * 2;
            int tanqueY = getHeight() - tamCelda * 2;
            g.setColor(Color.BLACK);
            g.fillRect(tanqueX - 15, tanqueY, 30, 20);
            g.fillRect(tanqueX - 5, tanqueY - 15, 10, 15);

            // Nave enemiga
            int ex = enemigoCeldaX * tamCelda;
            int ey = getHeight() - (enemigoCeldaY + 1) * tamCelda;
            g.fillRect(ex + 5, ey + 5, tamCelda - 10, tamCelda - 10);

            // Disparo
            if (dibujar) {
                g.drawLine(x0, y0, x1, y1);
            }
        }
    }
}

