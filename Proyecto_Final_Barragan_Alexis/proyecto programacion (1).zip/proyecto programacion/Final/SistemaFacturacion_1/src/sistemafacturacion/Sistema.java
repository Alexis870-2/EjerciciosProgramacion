package sistemafacturacion;

import com.opencsv.exceptions.CsvValidationException;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;

public class Sistema extends javax.swing.JFrame {

    private static GestionArchivos gestor = new GestionArchivos();
    private Factura factura = new Factura();
    DefaultTableModel modeloFactura = new DefaultTableModel();
    
    private void crearModelo() {
        modeloFactura.addColumn("Producto");
        modeloFactura.addColumn("Precio Unitario");
        modeloFactura.addColumn("Cantidad");
        modeloFactura.addColumn("Subtotal");
        
    }
    

    public Sistema() throws IOException, CsvValidationException {
        initComponents();
        this.setLocationRelativeTo(null);
        aplicarEstilos();
        igualarFecha();
        igualarFactura();
        configurarCampoTxtPrecio();
        crearModelo();
        listenerEliminarProductoEnTabla();
    }
    
    private void igualarFecha(){
        LocalDate fecha = LocalDate.now();
        txtFecha.setText(fecha.toString());
    }
    
    private void igualarFactura() throws CsvValidationException, IOException{
        String nuevaFactura = String.valueOf(generarNuevoIdCompra());
        txtFactura.setText(nuevaFactura);
    }
    
    private int getCantidad(){
        int cantidad = Integer.parseInt(jSpCantidad.getValue().toString());
        return cantidad;
    }
    
    private void listenerEliminarProductoEnTabla() {
    tblFactura.addMouseListener(new java.awt.event.MouseAdapter() {
        @Override
        public void mouseClicked(java.awt.event.MouseEvent evt) {
            int filaSeleccionada = tblFactura.getSelectedRow();

            // Verifica si no hay fila seleccionada o si el valor de la celda es null
            if (evt.getClickCount() == 2 && filaSeleccionada != -1) {
                Object valorCelda = tblFactura.getValueAt(filaSeleccionada, 0);
                if (valorCelda == null) {
                    return; // No hace nada si el valor es null
                }

                String nombreProducto = valorCelda.toString();

                int opcion = JOptionPane.showConfirmDialog(
                    null,
                    "¿Desea remover el producto \"" + nombreProducto + "\" de la factura?",
                    "Confirmar eliminación",
                    JOptionPane.YES_NO_OPTION
                );

                if (opcion == JOptionPane.YES_OPTION) {
                    String id = factura.obtenerIdPorNombre(nombreProducto);
                    if (id != null) {
                        factura.quitarProducto(id);

                        DefaultTableModel modelo = (DefaultTableModel) tblFactura.getModel();
                        modelo.removeRow(filaSeleccionada);
                    } else {
                        JOptionPane.showMessageDialog(null, "No se encontró el ID para el producto: " + nombreProducto);
                    }
                }
            }
        }
    });
}

    
    private void agregarProductoATabla(String producto, int cantidad){
        modeloFactura.setRowCount(0);
        String id = factura.obtenerIdPorNombre(producto);
        factura.agregarProducto(id, cantidad);
//        double subtotal = factura.getSubtotal();
//        double iva = factura.getIva();
//        double total = factura.getTotal();
        txtSubtotal.setText(String.valueOf(factura.getSubtotal()));
        txtIva.setText(String.valueOf(factura.getIva()));
        txtTotal.setText(String.valueOf(factura.getTotal()));
        
        List<Producto> productosAgregados = factura.getProductosAgregados();
        for (Producto pa : productosAgregados) {
            modeloFactura.addRow(new Object[]{pa.getNombre(), pa.getPrecio(), 
                        factura.getcantidadProductoAgregado(pa.getNombre()), 
                        (pa.getPrecio()*factura.getcantidadProductoAgregado(pa.getNombre()))});
        }
        tblFactura.setModel(modeloFactura);
        
    }
    
    
    private boolean registrarCompra() throws CsvValidationException, IOException {
        if (factura.confirmarFactura()) {
        try {
            List<Cliente> clientes = gestor.loadClientes();
            if (clientes.isEmpty()) {
                JOptionPane.showMessageDialog(null,"No hay clientes registrados. Primero agrega un cliente.");return false;}
            List<Producto> productos = gestor.loadProductos();
            if (productos.isEmpty()) {
                JOptionPane.showMessageDialog(null,"No hay productos registrados. Primero agrega un producto.");return false;}
            List<Compra> compras = gestor.loadCompras();
            
            int idCliente = gestor.getClientePorDocumento(txtDocumento.getText()).getId();
            int idProducto = gestor.searchProductoByName(txtProducto.getText()).getId();
            Producto productoElegido = gestor.searchProductoByName(txtProducto.getText());
            
            if (productoElegido == null) {
                JOptionPane.showMessageDialog(null, "nombre de producto inválido.");
                return false;
            }
            int cantidad = getCantidad();
            LocalDate fecha = LocalDate.now();
            
            Compra compra = new Compra(generarNuevoIdCompra(compras), idCliente, idProducto, cantidad, fecha);
            gestor.addCompra(compra);
            JOptionPane.showMessageDialog(null, "Compra registrada correctamente. Fecha: " + fecha);
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error al registrar compra: " + e.getMessage());
        }
        
        return true;
        }
        return false;
    }

    private void agregarCliente() throws CsvValidationException {
        try {
            List<Cliente> clientes = gestor.loadClientes();
            int nuevoId = generarNuevoIdClientes(clientes);
            String documento = txtDocumento.getText();
            String apellido = txtApellido.getText();
            String nombre = txtNombre.getText();
            String telefono = txtTelefono.getText();
            String correo = txtCorreo.getText();
            String direccion = txtDireccion.getText();

            Cliente c = new Cliente(nuevoId, documento, apellido, nombre, telefono, correo, direccion);
            if (gestor.clienteExistePorDocumento(documento)) {
                gestor.addCliente(c);
            } else {
                gestor.addCliente(c);
                JOptionPane.showMessageDialog(null, "Cliente agregado correctamente.");
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error al agregar cliente: " + e.getMessage());
        }
    }
    
    private void agregarProducto() throws CsvValidationException {
        try {
            List<Producto> productos = gestor.loadProductos();
            int nuevoId = generarNuevoIdProductos(productos);
            String producto = txtProducto.getText();
            double precio = getPrecio();
            int stock = leerEntero(jSpCantidad.getValue().toString());
            
            Producto p = new Producto(nuevoId, producto, precio, stock);
            if (gestor.productoExistePorNombre(producto)) {
                gestor.addProducto(p);
                Producto actualizado = gestor.searchProductoByName(producto);
                String precioActualizado = String.valueOf(actualizado.getPrecio());
                String stockActualizado = String.valueOf(actualizado.getStock());
                setDatosProducto(producto, precioActualizado, stockActualizado);
                factura.agregarOActualizarProducto(p.getId(), p.getNombre(), p.getPrecio(), p.getStock());
            } else {
                gestor.addProducto(p);
                factura.agregarOActualizarProducto(p.getId(), p.getNombre(), p.getPrecio(), p.getStock());
                JOptionPane.showMessageDialog(null, "Producto agregado correctamente.");
                setDatosProducto(producto, String.valueOf(precio), String.valueOf(stock));
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error al agregar cliente: " + e.getMessage());
        }
    }
        

    private static int generarNuevoIdClientes(List<Cliente> clientes) {
        int maxId = 0;
        for (Cliente c : clientes) {
            if (c.getId() > maxId) {
                maxId = c.getId();
            }
        }
        return maxId + 1;
    }
    
    private static int generarNuevoIdProductos(List<Producto> productos) {
        int maxId = 0;
        for (Producto p : productos) {
            if (p.getId()> maxId) {
                maxId = p.getId();
            }
        }
        return maxId + 1;
    }
    
    private static int generarNuevoIdCompra() throws CsvValidationException, IOException {
        List<Compra> compras = gestor.loadCompras();
        int maxId = 0;
        for (Compra c : compras) {
            if (c.getIdCompra()> maxId) {
                maxId = c.getIdCompra();
            }
        }
        return maxId + 1;
    }
    private static int generarNuevoIdCompra(List<Compra> compras) throws CsvValidationException, IOException {
        int maxId = 0;
        for (Compra c : compras) {
            if (c.getIdCompra()> maxId) {
                maxId = c.getIdCompra();
            }
        }
        return maxId + 1;
    }

    public void setDatosCliente(String documento, String apellido, String nombre, String telefono, String correo, String direccion) {
        txtDocumento.setText(documento);
        txtApellido.setText(apellido);
        txtNombre.setText(nombre);
        txtTelefono.setText(telefono);
        txtCorreo.setText(correo);
        txtDireccion.setText(direccion);
    }
    
    public void setDatosProducto(String producto, String precio, String stock) {
        txtProducto.setText(producto);
        txtPrecio.setText(precio);
        formatearPrecio();
        labelStock.setText("Disponibles: "+stock);
    }

    private boolean isFormularioCompleto() {
        boolean completo = false;
        if (txtDocumento.getText().isEmpty()) {
            return completo;
        }
        if (txtApellido.getText().isEmpty()) {
            return completo;
        }
        if (txtNombre.getText().isEmpty()) {
            return completo;
        }
        if (txtTelefono.getText().isEmpty()) {
            return completo;
        }
        if (txtCorreo.getText().isEmpty()) {
            return completo;
        }
        if (txtDireccion.getText().isEmpty()) {
            return completo;
        }
        return true;
    }
    
    private boolean isFormularioProductoCompleto() {
        boolean completo = false;
        if (txtProducto.getText().isEmpty()) {
            return completo;
        }
        if (txtPrecio.getText().isEmpty()) {
            return completo;
        }
        if (jSpCantidad.getValue().toString().isEmpty()) {
            return completo;
        }
        return true;
    }
    
    private boolean validarFormularioProductoCompleto() {
        if (isFormularioProductoCompleto()) {
            return imprimirProducto();
        } else {
            JOptionPane.showMessageDialog(null, "Datos incompletos. Por favor revisar");
        }
        return isFormularioProductoCompleto();
    }
    
    private boolean imprimirProducto() {
        String datosProducto = "¿Está seguro que desea guardar este Producto?\n"
                + "Producto: " + txtProducto.getText() + "\n"
                + "Precio: " + txtPrecio.getText() + "\n"
                + "Stock: " + jSpCantidad.getValue() + "\n";
        int opcion = JOptionPane.showConfirmDialog(null, datosProducto, "Confirmación", JOptionPane.YES_NO_OPTION);
        return opcion == JOptionPane.YES_OPTION;
    }

    private boolean imprimirCliente() {
        String datosCliente = "¿Está seguro que desea guardar a este cliente?\n"
                + "Documento: " + txtDocumento.getText() + "\n"
                + "Apellido: " + txtApellido.getText() + "\n"
                + "Nombre: " + txtNombre.getText() + "\n"
                + "Teléfono: " + txtTelefono.getText() + "\n"
                + "Correo: " + txtCorreo.getText() + "\n"
                + "Dirección: " + txtDireccion.getText() + "\n";
        int opcion = JOptionPane.showConfirmDialog(null, datosCliente, "Confirmación", JOptionPane.YES_NO_OPTION);
        return opcion == JOptionPane.YES_OPTION;
    }

    private boolean validarFormularioCompleto() {
        if (isFormularioCompleto()) {
            return imprimirCliente();
        } else {
            JOptionPane.showMessageDialog(null, "Datos incompletos. Por favor revisar");
        }
        return isFormularioCompleto();
    }
    
    private boolean isClienteValido() throws IOException, CsvValidationException{
        return gestor.clienteExistePorDocumento(txtDocumento.getText());
    }
    
    private boolean isFacturaValida(){
        return factura.getProductosAgregados().isEmpty();
    }
    
    private boolean isFacturaLista() throws IOException, CsvValidationException{
        if (!isClienteValido()) {
            JOptionPane.showMessageDialog(null, "El cliente seleccionado no es válido");
            return false;
        }
        
        if (isFacturaValida()) {
            JOptionPane.showMessageDialog(null, "No se han agregado productos");
            return false;
        }
        return true;
    }
    
    private void limpiarComponentes() throws CsvValidationException, IOException {
        setDatosCliente("", "", "", "", "", "");
        igualarFactura();
        setDatosProducto("", "", "");
        txtPrecio.setText("");
        modeloFactura.setRowCount(0);
        txtSubtotal.setText("0,00");
        txtIva.setText("0,00");
        txtTotal.setText("0,00");
        
    }
    
    
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jPanel8 = new javax.swing.JPanel();
        txtDocumento = new javax.swing.JTextField();
        labelDocumento = new javax.swing.JLabel();
        labelApellido = new javax.swing.JLabel();
        txtApellido = new javax.swing.JTextField();
        txtNombre = new javax.swing.JTextField();
        labelNombre = new javax.swing.JLabel();
        jPanel9 = new javax.swing.JPanel();
        txtTelefono = new javax.swing.JTextField();
        labelTelefono = new javax.swing.JLabel();
        labelCorreo = new javax.swing.JLabel();
        txtCorreo = new javax.swing.JTextField();
        txtDireccion = new javax.swing.JTextField();
        labelDireccion = new javax.swing.JLabel();
        jLabelCliente = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        btnBuscarCliente = new javax.swing.JButton();
        btnGuardar = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jPanel7 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblFactura = new javax.swing.JTable();
        jPanel10 = new javax.swing.JPanel();
        labelProducto = new javax.swing.JLabel();
        labelPrecio = new javax.swing.JLabel();
        labelCantidad = new javax.swing.JLabel();
        txtPrecio = new javax.swing.JTextField();
        txtProducto = new javax.swing.JTextField();
        jSpCantidad = new javax.swing.JSpinner();
        btnCrearProducto = new javax.swing.JButton();
        labelStock = new javax.swing.JLabel();
        jPanel11 = new javax.swing.JPanel();
        btnBuscarProductos = new javax.swing.JButton();
        btnAgregarCompra = new javax.swing.JButton();
        jPanel12 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        txtSubtotal = new javax.swing.JTextField();
        txtIva = new javax.swing.JTextField();
        txtTotal = new javax.swing.JTextField();
        jPanel13 = new javax.swing.JPanel();
        btnGenerarFactura = new javax.swing.JButton();
        labelFactura = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txtFactura = new javax.swing.JTextField();
        txtFecha = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setLocation(new java.awt.Point(0, 0));
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(174, 232, 232));

        jPanel2.setBackground(new java.awt.Color(204, 255, 255));

        jPanel5.setBackground(new java.awt.Color(255, 255, 255));
        jPanel5.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jPanel8.setBackground(new java.awt.Color(255, 255, 255));

        txtDocumento.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtDocumento.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtDocumentoFocusLost(evt);
            }
        });
        txtDocumento.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtDocumentoActionPerformed(evt);
            }
        });

        labelDocumento.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        labelDocumento.setText("#Documento:");

        labelApellido.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        labelApellido.setText("Apellido:");

        txtApellido.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        txtNombre.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        labelNombre.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        labelNombre.setText("Nombre:");

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addComponent(labelDocumento)
                        .addGap(6, 6, 6)
                        .addComponent(txtDocumento, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addComponent(labelApellido)
                        .addGap(6, 6, 6)
                        .addComponent(txtApellido, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addComponent(labelNombre)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtNombre)))
                .addContainerGap(18, Short.MAX_VALUE))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtDocumento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(labelDocumento))
                .addGap(6, 6, 6)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtApellido, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(labelApellido))
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGap(9, 9, 9)
                        .addComponent(labelNombre))
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(txtNombre)))
                .addContainerGap())
        );

        jPanel9.setBackground(new java.awt.Color(255, 255, 255));
        jPanel9.setPreferredSize(new java.awt.Dimension(236, 114));

        txtTelefono.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        labelTelefono.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        labelTelefono.setText("Teléfono:");

        labelCorreo.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        labelCorreo.setText("Correo:");

        txtCorreo.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtCorreo.setToolTipText("");
        txtCorreo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCorreoActionPerformed(evt);
            }
        });

        txtDireccion.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtDireccion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtDireccionActionPerformed(evt);
            }
        });

        labelDireccion.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        labelDireccion.setText("Dirección:");

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addComponent(labelTelefono)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtTelefono, javax.swing.GroupLayout.DEFAULT_SIZE, 150, Short.MAX_VALUE))
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(labelDireccion)
                            .addComponent(labelCorreo))
                        .addGap(8, 8, 8)
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtDireccion)
                            .addComponent(txtCorreo))))
                .addGap(10, 10, 10))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel9Layout.createSequentialGroup()
                .addContainerGap(18, Short.MAX_VALUE)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(labelTelefono)
                    .addComponent(txtTelefono, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(6, 6, 6)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(labelCorreo)
                    .addComponent(txtCorreo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(6, 6, 6)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(labelDireccion)
                    .addComponent(txtDireccion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        jLabelCliente.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabelCliente.setText("CLIENTE");
        jLabelCliente.setName("Titulo"); // NOI18N

        jPanel6.setBackground(new java.awt.Color(255, 255, 255));
        jPanel6.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jPanel6.setPreferredSize(new java.awt.Dimension(236, 114));

        btnBuscarCliente.setBackground(new java.awt.Color(0, 153, 153));
        btnBuscarCliente.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        btnBuscarCliente.setForeground(new java.awt.Color(255, 255, 255));
        btnBuscarCliente.setText("Buscar Cliente");
        btnBuscarCliente.setBorder(new javax.swing.border.MatteBorder(null));
        btnBuscarCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarClienteActionPerformed(evt);
            }
        });

        btnGuardar.setBackground(new java.awt.Color(0, 204, 0));
        btnGuardar.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        btnGuardar.setForeground(new java.awt.Color(255, 255, 255));
        btnGuardar.setText("Guardar Cliente");
        btnGuardar.setBorder(new javax.swing.border.MatteBorder(null));
        btnGuardar.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                .addContainerGap(26, Short.MAX_VALUE)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnGuardar, javax.swing.GroupLayout.PREFERRED_SIZE, 185, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnBuscarCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 185, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(25, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap(13, Short.MAX_VALUE)
                .addComponent(btnBuscarCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnGuardar, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(13, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabelCliente, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabelCliente)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jPanel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        jPanel5.getAccessibleContext().setAccessibleName("jp2");

        jPanel4.setBackground(new java.awt.Color(204, 255, 255));

        jPanel7.setBackground(new java.awt.Color(255, 255, 255));
        jPanel7.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        tblFactura.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Producto", "Precio Unitario", "Cantidad", "Subtotal"
            }
        ));
        jScrollPane1.setViewportView(tblFactura);

        jPanel10.setBackground(new java.awt.Color(255, 255, 255));

        labelProducto.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        labelProducto.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        labelProducto.setText("Producto");

        labelPrecio.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        labelPrecio.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        labelPrecio.setText("Precio ($)");

        labelCantidad.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        labelCantidad.setText("Cantidad");

        txtPrecio.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtPrecio.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        txtPrecio.setText("0,00");
        txtPrecio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPrecioActionPerformed(evt);
            }
        });

        txtProducto.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        jSpCantidad.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jSpCantidad.setModel(new javax.swing.SpinnerNumberModel(0, 0, null, 1));

        btnCrearProducto.setBackground(new java.awt.Color(0, 102, 102));
        btnCrearProducto.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        btnCrearProducto.setForeground(new java.awt.Color(255, 255, 255));
        btnCrearProducto.setText("Crear producto");
        btnCrearProducto.setBorder(new javax.swing.border.MatteBorder(null));
        btnCrearProducto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCrearProductoActionPerformed(evt);
            }
        });

        labelStock.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        labelStock.setText("Disponibles:");

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(labelProducto, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txtProducto, javax.swing.GroupLayout.DEFAULT_SIZE, 150, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(labelPrecio, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txtPrecio, javax.swing.GroupLayout.DEFAULT_SIZE, 70, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jSpCantidad, javax.swing.GroupLayout.DEFAULT_SIZE, 80, Short.MAX_VALUE)
                            .addComponent(labelCantidad, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(labelStock, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addComponent(btnCrearProducto, javax.swing.GroupLayout.PREFERRED_SIZE, 185, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(labelProducto)
                    .addComponent(labelPrecio)
                    .addComponent(labelCantidad))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtProducto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtPrecio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jSpCantidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(labelStock))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnCrearProducto, javax.swing.GroupLayout.DEFAULT_SIZE, 35, Short.MAX_VALUE)
                .addGap(12, 12, 12))
        );

        jPanel11.setBackground(new java.awt.Color(255, 255, 255));
        jPanel11.setPreferredSize(new java.awt.Dimension(236, 114));

        btnBuscarProductos.setBackground(new java.awt.Color(0, 153, 153));
        btnBuscarProductos.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        btnBuscarProductos.setForeground(new java.awt.Color(255, 255, 255));
        btnBuscarProductos.setText("Buscar Productos");
        btnBuscarProductos.setBorder(new javax.swing.border.MatteBorder(null));
        btnBuscarProductos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarProductosActionPerformed(evt);
            }
        });

        btnAgregarCompra.setBackground(new java.awt.Color(0, 204, 0));
        btnAgregarCompra.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        btnAgregarCompra.setForeground(new java.awt.Color(255, 255, 255));
        btnAgregarCompra.setText("Agregar a la compra");
        btnAgregarCompra.setBorder(new javax.swing.border.MatteBorder(null));
        btnAgregarCompra.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregarCompraActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel11Layout.createSequentialGroup()
                .addContainerGap(26, Short.MAX_VALUE)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnAgregarCompra, javax.swing.GroupLayout.PREFERRED_SIZE, 185, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnBuscarProductos, javax.swing.GroupLayout.PREFERRED_SIZE, 185, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(25, 25, 25))
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addGap(13, 13, 13)
                .addComponent(btnBuscarProductos, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnAgregarCompra, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(13, Short.MAX_VALUE))
        );

        jPanel12.setBackground(new java.awt.Color(255, 255, 255));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel3.setText("Subtotal:");

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel4.setText("IVA 15%:");

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel5.setText("Total:");

        txtSubtotal.setEditable(false);
        txtSubtotal.setBackground(java.awt.Color.lightGray);
        txtSubtotal.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtSubtotal.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtSubtotal.setText("0,00");
        txtSubtotal.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        txtIva.setEditable(false);
        txtIva.setBackground(java.awt.Color.lightGray);
        txtIva.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtIva.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtIva.setText("0,00");
        txtIva.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        txtTotal.setEditable(false);
        txtTotal.setBackground(java.awt.Color.lightGray);
        txtTotal.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtTotal.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtTotal.setText("0,00");
        txtTotal.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        txtTotal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTotalActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
        jPanel12.setLayout(jPanel12Layout);
        jPanel12Layout.setHorizontalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel12Layout.createSequentialGroup()
                        .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel12Layout.createSequentialGroup()
                                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(txtTotal, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel12Layout.createSequentialGroup()
                                .addComponent(jLabel3)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtIva, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtSubtotal, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel12Layout.setVerticalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(txtSubtotal, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(txtIva, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(txtTotal, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(11, Short.MAX_VALUE))
        );

        jPanel13.setBackground(new java.awt.Color(255, 255, 255));

        btnGenerarFactura.setBackground(new java.awt.Color(0, 102, 102));
        btnGenerarFactura.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        btnGenerarFactura.setForeground(new java.awt.Color(255, 255, 255));
        btnGenerarFactura.setText("Generar Factura");
        btnGenerarFactura.setBorder(new javax.swing.border.MatteBorder(null));
        btnGenerarFactura.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGenerarFacturaActionPerformed(evt);
            }
        });

        labelFactura.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        labelFactura.setText("FACTURA");

        javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
        jPanel13.setLayout(jPanel13Layout);
        jPanel13Layout.setHorizontalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel13Layout.createSequentialGroup()
                .addContainerGap(284, Short.MAX_VALUE)
                .addComponent(btnGenerarFactura, javax.swing.GroupLayout.PREFERRED_SIZE, 185, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addComponent(labelFactura)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel13Layout.setVerticalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addComponent(labelFactura)
                .addGap(10, 10, 10)
                .addComponent(btnGenerarFactura, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScrollPane1)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(jPanel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(18, 18, 18)
                        .addComponent(jPanel11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jPanel13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jPanel12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel1.setText("N° de Factura:");

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel2.setText("Fecha:");

        txtFactura.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtFactura.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtFacturaActionPerformed(evt);
            }
        });

        txtFecha.setEditable(false);
        txtFecha.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtFecha.setText("dd/mm/aaaa");
        txtFecha.setOpaque(true);
        txtFecha.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtFechaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtFactura, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(55, 55, 55)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtFecha, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jLabel2)
                    .addComponent(txtFactura, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtFecha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(6, 6, 6))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtDireccionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtDireccionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtDireccionActionPerformed

    private void txtDocumentoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtDocumentoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtDocumentoActionPerformed

    private void txtCorreoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCorreoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCorreoActionPerformed

    private void btnBuscarClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarClienteActionPerformed
       
        TablaClientes tabla = new TablaClientes(this);
        tabla.setVisible(true);

    }//GEN-LAST:event_btnBuscarClienteActionPerformed

    private void txtFechaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtFechaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtFechaActionPerformed

    private void txtFacturaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtFacturaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtFacturaActionPerformed

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed

        if (validarFormularioCompleto()) {
            try {
                agregarCliente();
            } catch (CsvValidationException ex) {
                Logger.getLogger(Sistema.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

    }//GEN-LAST:event_btnGuardarActionPerformed

    private void btnBuscarProductosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarProductosActionPerformed
        
        TablaProductos tabla = new TablaProductos(this);
        tabla.setVisible(true);
        
    }//GEN-LAST:event_btnBuscarProductosActionPerformed

    private void txtTotalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTotalActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTotalActionPerformed

    private void btnGenerarFacturaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGenerarFacturaActionPerformed
        
        try {
            if (isFacturaLista()) {
                try {
                    if (registrarCompra()) {
                        File pdf = GeneradorFacturaPDF.generarFacturaPDF(factura,
                            gestor.getClientePorDocumento(txtDocumento.getText()), txtFactura.getText());
                    new VistaFacturaPDF(pdf);
                    factura.guardarCambios();
                    limpiarComponentes();
                    }
                } catch (IOException ex) {
                    JOptionPane.showMessageDialog(null, "Error generando factura: " + ex.getMessage());
                }
                
            }


        } catch (Exception ex) {
            Logger.getLogger(Sistema.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }//GEN-LAST:event_btnGenerarFacturaActionPerformed

    private void btnCrearProductoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCrearProductoActionPerformed
        // TODO add your handling code here:
        if (validarFormularioProductoCompleto()) {
            try {
                agregarProducto();
                
            } catch (CsvValidationException ex) {
                Logger.getLogger(Sistema.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }//GEN-LAST:event_btnCrearProductoActionPerformed

    private void btnAgregarCompraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregarCompraActionPerformed
        
        
        agregarProductoATabla(txtProducto.getText(), getCantidad());
        

    }//GEN-LAST:event_btnAgregarCompraActionPerformed

    private void txtPrecioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPrecioActionPerformed
        // TODO add your handling code here:
        
    }//GEN-LAST:event_txtPrecioActionPerformed

    private void txtDocumentoFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtDocumentoFocusLost
        try {
            // TODO add your handling code here:
            completarClientePorDocumento(txtDocumento.getText());
        
        } catch (Exception ex) {
            Logger.getLogger(Sistema.class.getName()).log(Level.SEVERE, null, ex);}
        
        
    }//GEN-LAST:event_txtDocumentoFocusLost

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Sistema.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Sistema.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Sistema.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Sistema.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    new Sistema().setVisible(true);
                } catch (IOException ex) {
                    Logger.getLogger(Sistema.class.getName()).log(Level.SEVERE, null, ex);
                } catch (CsvValidationException ex) {
                    Logger.getLogger(Sistema.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }
    
    private static int leerEntero(String valor) {
                int val = Integer.parseInt(valor);
                return val;
    }

    private static double leerDouble(String valor) {
                double val = Double.parseDouble(valor);
                return val;
        
    }
    
    //==========================Métodos para trabajar con el precio===================================

    private void configurarCampoTxtPrecio() {
        // Eliminar el texto inicial y establecer placeholder
        txtPrecio.setText("0,00");
        
        // Agregar KeyListener para validar entradas
        txtPrecio.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                validarEntradaNumerica(evt);
            }
            
            public void keyPressed(java.awt.event.KeyEvent evt) {
                // Limpiar el placeholder cuando el usuario comienza a escribir
                if (txtPrecio.getText().equals("0,00")) {
                    txtPrecio.setText("");
                }
            }
        });
        
        // Agregar FocusListener para formatear cuando pierde el foco
        txtPrecio.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                formatearPrecio();
            }
            
            public void focusGained(java.awt.event.FocusEvent evt) {
                // Cuando gana foco, si tiene el placeholder, seleccionar todo
                if (txtPrecio.getText().equals("0,00")) {
                    txtPrecio.selectAll();
                }
            }
        });
    }
    
    private void validarEntradaNumerica(java.awt.event.KeyEvent evt) {
        char caracter = evt.getKeyChar();
        
        // Permitir solo dígitos, punto decimal y teclas de control
        if (!Character.isDigit(caracter) && caracter != '.' && caracter != ',' && caracter != 8) {
            evt.consume(); // Ignorar el caracter si no cumple con los requisitos
            return;
        }
        
        // Convertir comas a puntos para consistencia
        if (caracter == ',') {
            evt.setKeyChar('.');
        }
        
        String texto = txtPrecio.getText();
        
        // Verificar que no haya más de un punto decimal
        if (caracter == '.' && texto.contains(".")) {
            evt.consume();
        }
        
        // Verificar que no haya más de 2 dígitos después del punto decimal
        if (Character.isDigit(caracter) && texto.contains(".")) {
            int puntoPos = texto.indexOf(".");
            if (texto.length() - puntoPos > 2) {
                evt.consume();
            }
        }
    }
      private void formatearPrecio() {
        try {
            String texto = txtPrecio.getText().trim();
            
            if (texto.isEmpty()) {
                txtPrecio.setText("0,00");
                return;
            }
            
            // Reemplazar comas por puntos para el parsing
            texto = texto.replace(',', '.');
            
            double valor = Double.parseDouble(texto);
            
            if (valor < 0) {
                // No permitir valores negativos
                valor = Math.abs(valor);
            }
            
            // Formatear con 2 decimales sin separador de miles
            java.text.DecimalFormat formatoNumero = new java.text.DecimalFormat("#0.00");
            formatoNumero.setDecimalFormatSymbols(new java.text.DecimalFormatSymbols(java.util.Locale.forLanguageTag("es-ES")));
            
            txtPrecio.setText(formatoNumero.format(valor));
        } catch (NumberFormatException e) {
            txtPrecio.setText("0,00");
        }
    }
    
    // Método para obtener el valor del precio como double
    public double getPrecio() {
        try {
            String texto = txtPrecio.getText().trim().replace(".", "").replace(",", ".");
            return Double.parseDouble(texto);
        } catch (NumberFormatException e) {
            return 0.0;
        }
    }
    
    public void aplicarEstilos() {
        // Forzar el renderizado del encabezado con color personalizado
        // ======= ESTILO DEL ENCABEZADO =======
        JTableHeader header = tblFactura.getTableHeader();
        header.setDefaultRenderer(new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                    boolean isSelected, boolean hasFocus, int row, int column) {
                JLabel label = (JLabel) super.getTableCellRendererComponent(
                        table, value, isSelected, hasFocus, row, column);
                label.setFont(new Font("Segoe UI", Font.BOLD, 15));
                label.setBackground(new Color(30, 144, 255)); // Azul moderno
                label.setForeground(Color.WHITE);
                label.setOpaque(true);
                label.setHorizontalAlignment(SwingConstants.CENTER);
                return label;
            }
        });

        // ======= ESTILO DEL CUERPO DE LA TABLA =======
        DefaultTableCellRenderer cellRenderer = new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                    boolean isSelected, boolean hasFocus, int row, int column) {

                JLabel label = (JLabel) super.getTableCellRendererComponent(
                        table, value, isSelected, hasFocus, row, column);

                label.setFont(new Font("Segoe UI", Font.PLAIN, 13));
                label.setHorizontalAlignment(SwingConstants.CENTER);
                label.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

                if (!isSelected) {
                    // Alternancia de filas
                    if (row % 2 == 0) {
                        label.setBackground(new Color(245, 248, 255)); // Azul muy suave
                    } else {
                        label.setBackground(Color.WHITE);
                    }
                    label.setForeground(new Color(50, 50, 50)); // Texto oscuro
                } else {
                    label.setBackground(new Color(100, 149, 237)); // Azul de selección
                    label.setForeground(Color.WHITE);
                }

                label.setOpaque(true);
                return label;
            }
        };

        // Aplicar render a todas las columnas
        for (int i = 0; i < tblFactura.getColumnCount(); i++) {
            tblFactura.getColumnModel().getColumn(i).setCellRenderer(cellRenderer);
        }

        // ======= AJUSTES GENERALES DE LA TABLA =======
        tblFactura.setRowHeight(28);
        tblFactura.setShowGrid(true);
        tblFactura.setGridColor(new Color(220, 220, 220));
        tblFactura.setIntercellSpacing(new Dimension(1, 1));
        tblFactura.setSelectionBackground(new Color(100, 149, 237));
        tblFactura.setSelectionForeground(Color.WHITE);
        tblFactura.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        tblFactura.setFocusable(false);
        tblFactura.setRowSelectionAllowed(true);
        tblFactura.setColumnSelectionAllowed(false);
        tblFactura.setDefaultEditor(Object.class, null); // Hacer no editable desde la tabla
    }

        
    
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAgregarCompra;
    private javax.swing.JButton btnBuscarCliente;
    private javax.swing.JButton btnBuscarProductos;
    private javax.swing.JButton btnCrearProducto;
    private javax.swing.JButton btnGenerarFactura;
    private javax.swing.JButton btnGuardar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabelCliente;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSpinner jSpCantidad;
    private javax.swing.JLabel labelApellido;
    private javax.swing.JLabel labelCantidad;
    private javax.swing.JLabel labelCorreo;
    private javax.swing.JLabel labelDireccion;
    private javax.swing.JLabel labelDocumento;
    private javax.swing.JLabel labelFactura;
    private javax.swing.JLabel labelNombre;
    private javax.swing.JLabel labelPrecio;
    private javax.swing.JLabel labelProducto;
    private javax.swing.JLabel labelStock;
    private javax.swing.JLabel labelTelefono;
    private javax.swing.JTable tblFactura;
    private javax.swing.JTextField txtApellido;
    private javax.swing.JTextField txtCorreo;
    private javax.swing.JTextField txtDireccion;
    private javax.swing.JTextField txtDocumento;
    private javax.swing.JTextField txtFactura;
    private javax.swing.JTextField txtFecha;
    private javax.swing.JTextField txtIva;
    private javax.swing.JTextField txtNombre;
    private javax.swing.JTextField txtPrecio;
    private javax.swing.JTextField txtProducto;
    private javax.swing.JTextField txtSubtotal;
    private javax.swing.JTextField txtTelefono;
    private javax.swing.JTextField txtTotal;
    // End of variables declaration//GEN-END:variables

    private void completarClientePorDocumento(String documento) throws IOException, CsvValidationException {
        if (gestor.clienteExistePorDocumento(documento)) {
            Cliente cliente = gestor.getClientePorDocumento(documento);
            setDatosCliente(documento, cliente.getApellido(), cliente.getNombre(), 
                    cliente.getTelefono(), cliente.getCorreo(), cliente.getDireccion());
        }
    }
    



    

    

    
}
