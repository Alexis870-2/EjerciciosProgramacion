package sistemafacturacion;

import com.opencsv.exceptions.CsvValidationException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import javax.swing.JOptionPane;

public class Factura {

    private List<Producto> productosDisponibles;
    private List<Producto> productosAgregados;
    private GestionArchivos gestor = new GestionArchivos();

    public Factura() throws IOException, CsvValidationException {
        productosDisponibles = gestor.loadProductos();
        productosAgregados = new ArrayList<>();
    }

    public void agregarProducto(String id) {
        for (Producto p : productosDisponibles) {
            if (String.valueOf(p.getId()).equals(id)) {
                if (p.getStock() > 0) {
                    p.setStock(p.getStock() - 1);
                    productosAgregados.add(new Producto(p.getId(), p.getNombre(), p.getPrecio(), 1));
                    JOptionPane.showMessageDialog(null, "Producto agregado: " + p.getNombre());
                } else {
                    JOptionPane.showMessageDialog(null, "Stock insuficiente para: " + p.getNombre(),
                            "Advertencia", JOptionPane.WARNING_MESSAGE);
                }
                return;
            }
        }
        JOptionPane.showMessageDialog(null, "Producto no encontrado.");
    }

    public void agregarOActualizarProducto(int id, String nombre, double precio, int stock) {
        for (Producto p : productosDisponibles) {
            if (p.getNombre().equalsIgnoreCase(nombre)) {
                p.setStock(p.getStock() + stock);
                return;
            }
        }
        // Si no existe, lo crea
        Producto nuevo = new Producto(id, nombre, precio, stock);
        productosDisponibles.add(nuevo);
    }

    public void quitarProducto(String id) {
        Iterator<Producto> iterator = productosAgregados.iterator();
        while (iterator.hasNext()) {
            Producto agregado = iterator.next();
            if (String.valueOf(agregado.getId()).equals(id)) {
                int cantidadAgregada = agregado.getStock(); // cantidad que se había agregado

                // Devolver toda la cantidad al stock disponible
                for (Producto p : productosDisponibles) {
                    if (String.valueOf(p.getId()).equals(id)) {
                        p.setStock(p.getStock() + cantidadAgregada);
                        break;
                    }
                }

                iterator.remove(); // Elimina el producto de la lista de agregados

                JOptionPane.showMessageDialog(null,
                        cantidadAgregada + " unidad(es) de " + agregado.getNombre() + " eliminadas de la factura.");
                return;
            }
        }

        JOptionPane.showMessageDialog(null, "Producto no está en la factura.");
    }

    public boolean confirmarFactura() {
        if (productosAgregados.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No hay productos en la factura.");
            return false;
        }

        int confirm = JOptionPane.showConfirmDialog(null,
                "¿Confirmar la factura y actualizar el stock?", "Confirmación", JOptionPane.YES_NO_OPTION);
        // Si el usuario no confirma

        return confirm == JOptionPane.YES_OPTION;
    }

    public void guardarCambios() throws IOException {
        gestor.saveProductos(productosDisponibles);
        //JOptionPane.showMessageDialog(null, "Factura confirmada y stock actualizado.");
        productosAgregados.clear(); // Limpiar la factura
    }

    // Métodos opcionales para mostrar los productos
//    public void mostrarProductosDisponibles() {
//        StringBuilder sb = new StringBuilder("Productos disponibles:\n");
//        for (Producto p : productosDisponibles) {
//            sb.append(p).append("\n");
//        }
//        JOptionPane.showMessageDialog(null, sb.toString());
//    }
    public void mostrarFactura() {
        if (productosAgregados.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Factura vacía.");
            return;
        }

        StringBuilder sb = new StringBuilder("Factura actual:\n");
        double total = 0.0;

        for (Producto p : productosAgregados) {
            double subtotal = p.getPrecio() * p.getStock();
            sb.append(p.getNombre())
                    .append(" x").append(p.getStock())
                    .append(" - $").append(p.getPrecio())
                    .append(" c/u = $").append(String.format("%.2f", subtotal))
                    .append("\n");
            total += subtotal;
        }

        double iva = total * 0.15;
        double totalConIVA = total + iva;

        sb.append(String.format("\nSubtotal: $%.2f\nIVA (15%%): $%.2f\nTotal: $%.2f", total, iva, totalConIVA));
        JOptionPane.showMessageDialog(null, sb.toString());
    }

    public double getSubtotal() {
        double subtotal = 0.0;
        for (Producto p : productosAgregados) {
            subtotal += p.getPrecio() * p.getStock();
        }
        return Math.round(subtotal * 100.0) / 100.0;
    }

    public double getIva() {
        double iva = getSubtotal() * 0.15;
        return Math.round(iva * 100.0) / 100.0;
    }

    public double getTotal() {
        double total = getSubtotal() + getIva();
        return Math.round(total * 100.0) / 100.0;
    }

    // Devuelve el ID de un producto a partir del nombre
    public String obtenerIdPorNombre(String nombre) {
        for (Producto p : productosDisponibles) {
            if (p.getNombre().equalsIgnoreCase(nombre)) {
                return String.valueOf(p.getId());
            }
        }
        //JOptionPane.showMessageDialog(null, "Producto con nombre '" + nombre + "' no encontrado.");
        return null;
    }

// Calcula el IVA del 15% sobre el total de productos agregados
    public double calcularIVA() {
        double total = 0.0;
        for (Producto p : productosAgregados) {
            total += p.getPrecio();
        }
        return total * 0.15;
    }

    public void agregarProducto(String id, int cantidad) {
        for (Producto p : productosDisponibles) {
            if (String.valueOf(p.getId()).equals(id)) {
                if (cantidad == 0) {
                    JOptionPane.showMessageDialog(null, "Seleccione una cantidad de 1 o superior");
                    return;
                }
                if (p.getStock() >= cantidad) {
                    p.setStock(p.getStock() - cantidad);

                    // Verifica si ya está en la lista de productos agregados
                    boolean encontrado = false;
                    for (Producto agregado : productosAgregados) {
                        if (String.valueOf(agregado.getId()).equals(id)) {
                            agregado.setStock(agregado.getStock() + cantidad);
                            encontrado = true;
                            break;
                        }
                    }

                    if (!encontrado) {
                        productosAgregados.add(new Producto(p.getId(), p.getNombre(), p.getPrecio(), cantidad));
                    }

                    JOptionPane.showMessageDialog(null,
                            cantidad + " unidad(es) de " + p.getNombre() + " agregadas a la factura.");
                } else {
                    JOptionPane.showMessageDialog(null,
                            "Stock insuficiente para " + p.getNombre()
                            + ". Disponible: " + p.getStock() + ", solicitado: " + cantidad,
                            "Advertencia", JOptionPane.WARNING_MESSAGE);
                }
                return;
            }
        }

        JOptionPane.showMessageDialog(null, "Producto no encontrado.");
    }

    /*USO
   String id = factura.obtenerIdPorNombre("Portátil");
if (id != null) {
    factura.agregarProducto(id);

     */
    public List<Producto> getProductosAgregados() {
        return productosAgregados;
    }

    public int getcantidadProductoAgregado(String nombre) {
        for (Producto p : productosAgregados) {
            if (p.getNombre().equalsIgnoreCase(nombre)) {
                return p.getStock(); // Aquí usamos el campo stock como cantidad agregada
            }
        }
        return 0; // Si no se encuentra el producto, retorna 0
    }

}
