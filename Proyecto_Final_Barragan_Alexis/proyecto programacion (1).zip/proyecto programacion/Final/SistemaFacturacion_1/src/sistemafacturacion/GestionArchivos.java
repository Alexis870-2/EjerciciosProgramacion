package sistemafacturacion;

import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;
import com.opencsv.exceptions.CsvValidationException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class GestionArchivos {

    private static final String PATH_CLIENTES = "src\\sistemafacturacion\\clientes.csv";
    private static final String PATH_PRODUCTOS = "src\\sistemafacturacion\\productos.csv";
    private static final String PATH_COMPRAS = "src\\sistemafacturacion\\compras.csv";

    // Leer clientes
    public List<Cliente> loadClientes() throws IOException, CsvValidationException {
        List<Cliente> clientes = new ArrayList<>();
        try (CSVReader reader = new CSVReader(new FileReader(PATH_CLIENTES))) {
            String[] line;
            reader.readNext(); // saltar encabezado
            while ((line = reader.readNext()) != null) {
                Cliente c = new Cliente(
                        Integer.parseInt(line[0]),
                        line[1],
                        line[2],
                        line[3],
                        line[4],
                        line[5],
                        line[6]
                );
                clientes.add(c);
            }
        }
        return clientes;
    }

    // Guardar lista completa de clientes
    public void saveClientes(List<Cliente> clientes) throws IOException {
        try (CSVWriter writer = new CSVWriter(new FileWriter(PATH_CLIENTES))) {
            writer.writeNext(new String[]{"id,documento,apellido,nombre,telefono,correo,direccion"}.length > 0
                    ? new String[]{"id", "documento", "apellido", "nombre", "telefono", "correo", "direccion"} : null);
            for (Cliente c : clientes) {
                writer.writeNext(new String[]{
                    String.valueOf(c.getId()),
                    c.getDocumento(),
                    c.getApellido(),
                    c.getNombre(),
                    c.getTelefono(),
                    c.getCorreo(),
                    c.getDireccion()
                });
            }
        }
    }
    
    public Cliente getClientePorDocumento(String documento) throws IOException, CsvValidationException {
        List<Cliente> clientes = loadClientes();
        for (Cliente c : clientes) {
            if (c.getDocumento().equals(documento)) {
                return c;
            }
        }
        Cliente ningunCliente = new Cliente(0, "0", "0", "0", "0", "0", "0");
        return ningunCliente;
    }

    // Verifica si existe un cliente con el documento dado
    public boolean clienteExistePorDocumento(String documento) throws IOException, CsvValidationException {
        List<Cliente> clientes = loadClientes();
        for (Cliente c : clientes) {
            if (c.getDocumento().equals(documento)) {
                return true;
            }
        }
        return false;
    }
    
    //Verifica si existe el producto
    boolean productoExistePorNombre(String producto) throws IOException, CsvValidationException {
        List<Producto> productos = loadProductos();
        for (Producto p : productos) {
            if (p.getNombre().equalsIgnoreCase(producto)) {
                return true;
            }
        }
        return false;
    }
    
    public Producto searchProductoByName(String producto) throws IOException, CsvValidationException {
        List<Producto> productos = loadProductos();
        for (Producto p : productos) {
            if (p.getNombre().equalsIgnoreCase(producto)) {
                return p;
            }
        }
        Producto vacio = new Producto(0, "vacio", 0, 0);
        return vacio;
    }
    
    

    // Añadir cliente
    public void addCliente(Cliente nuevoCliente) throws IOException, CsvValidationException {
    List<Cliente> clientes = loadClientes();

    if (clienteExistePorDocumento(nuevoCliente.getDocumento())) {
        for (int i = 0; i < clientes.size(); i++) {
            Cliente existente = clientes.get(i);
            if (existente.getDocumento().equals(nuevoCliente.getDocumento())) {
                int opcion = JOptionPane.showConfirmDialog(null, 
                    "El cliente ya existe. ¿Desea actualizarlo?", 
                    "Cliente existente", 
                    JOptionPane.YES_NO_OPTION);

                if (opcion == JOptionPane.YES_OPTION) {
                    // Conserva el ID del cliente original
                    Cliente actualizado = new Cliente(
                        existente.getId(),
                        nuevoCliente.getDocumento(),
                        nuevoCliente.getApellido(),
                        nuevoCliente.getNombre(),
                        nuevoCliente.getTelefono(),
                        nuevoCliente.getCorreo(),
                        nuevoCliente.getDireccion()
                    );
                    clientes.set(i, actualizado);
                    saveClientes(clientes);
                    JOptionPane.showMessageDialog(null, "Cliente actualizado correctamente.");
                } else {
                    JOptionPane.showMessageDialog(null, "Operación cancelada. No se guardaron cambios.");
                }
                return;
            }
        }
    } else {
        clientes.add(nuevoCliente);
        saveClientes(clientes);
    }
}
    

    // Leer productos
    public List<Producto> loadProductos() throws IOException, CsvValidationException {
        List<Producto> productos = new ArrayList<>();
        try (CSVReader reader = new CSVReader(new FileReader(PATH_PRODUCTOS))) {
            String[] line;
            reader.readNext();
            while ((line = reader.readNext()) != null) {
                Producto p = new Producto(
                        Integer.parseInt(line[0]),
                        line[1],
                        Double.parseDouble(line[2]),
                        Integer.parseInt(line[3])
                );
                productos.add(p);
            }
        }
        return productos;
    }

    // Guardar productos
    public void saveProductos(List<Producto> productos) throws IOException {
        try (CSVWriter writer = new CSVWriter(new FileWriter(PATH_PRODUCTOS))) {
            writer.writeNext(new String[]{"id", "nombre", "precio", "stock"});
            for (Producto p : productos) {
                writer.writeNext(new String[]{
                    String.valueOf(p.getId()),
                    p.getNombre(),
                    String.valueOf(p.getPrecio()),
                    String.valueOf(p.getStock())
                });
            }
        }
    }

    // Añadir producto
    public void addProducto(Producto nuevoProducto) throws IOException, CsvValidationException {
        List<Producto> productos = loadProductos();
        if (productoExistePorNombre(nuevoProducto.getNombre())) {
        for (int i = 0; i < productos.size(); i++) {
            Producto existente = productos.get(i);
            if (existente.getNombre().equalsIgnoreCase(nuevoProducto.getNombre())) {
                int opcion = JOptionPane.showConfirmDialog(null, 
                    "El producto ya existe. ¿Desea sumar la cantidad al stock actual y actualizar el precio?", 
                    "Producto existente", 
                    JOptionPane.YES_NO_OPTION);

                if (opcion == JOptionPane.YES_OPTION) {
                    // Conserva el ID del producto original
                    Producto actualizado = new Producto(
                        existente.getId(),
                        nuevoProducto.getNombre(),
                        nuevoProducto.getPrecio(),
                        nuevoProducto.getStock() + existente.getStock()
                    );
                    productos.set(i, actualizado);
                    saveProductos(productos);
                    JOptionPane.showMessageDialog(null, "Producto actualizado correctamente.");
                } else {
                    JOptionPane.showMessageDialog(null, "Operación cancelada. No se guardaron cambios.");
                }
                return;
            }
        }
    }else{
        productos.add(nuevoProducto);
        saveProductos(productos);
        }
    }

    // Registrar compra y actualizar stock
    public void addCompra(Compra compra) throws IOException, CsvValidationException {
        // Cargar productos
        List<Producto> productos = loadProductos();
        for (Producto p : productos) {
            if (p.getId() == compra.getIdProducto()) {
                int nuevoStock = p.getStock() - compra.getCantidad();
                p.setStock(nuevoStock);
                break;
            }
        }
        saveProductos(productos);

        // Guardar compra
        try (CSVWriter writer = new CSVWriter(new FileWriter(PATH_COMPRAS, true))) {
            writer.writeNext(new String[]{
                String.valueOf(compra.getIdCompra()),
                String.valueOf(compra.getIdCliente()),
                String.valueOf(compra.getIdProducto()),
                String.valueOf(compra.getCantidad()),
                compra.getFecha().toString()
            });
        }
    }

    // En GestionArchivos:
    public List<Compra> loadCompras() throws IOException, CsvValidationException {
        List<Compra> compras = new ArrayList<>();
        try (CSVReader reader = new CSVReader(new FileReader(PATH_COMPRAS))) {
            String[] line;
            reader.readNext(); // si pusiste encabezado en el CSV; si no, omitir esta línea
            while ((line = reader.readNext()) != null) {
                int id = Integer.parseInt(line[0]);
                int idCliente = Integer.parseInt(line[1]);
                int idProducto = Integer.parseInt(line[2]);
                int cantidad = Integer.parseInt(line[3]);
                LocalDate fecha = LocalDate.parse(line[4]);
                compras.add(new Compra(id, idCliente, idProducto, cantidad, fecha));
            }
        }
        return compras;
    }
    
    // Guardar productos
    public void saveCompra(List<Producto> productos) throws IOException {
        try (CSVWriter writer = new CSVWriter(new FileWriter(PATH_PRODUCTOS))) {
            writer.writeNext(new String[]{"id", "nombre", "precio", "stock"});
            for (Producto p : productos) {
                writer.writeNext(new String[]{
                    String.valueOf(p.getId()),
                    p.getNombre(),
                    String.valueOf(p.getPrecio()),
                    String.valueOf(p.getStock())
                });
            }
        }
    }

    

}
