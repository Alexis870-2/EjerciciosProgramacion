package sistemafacturacion;

import java.io.File;
import org.apache.pdfbox.pdmodel.*;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import java.io.IOException;
import java.time.LocalDate;
import org.apache.pdfbox.pdmodel.font.PDFont;
import org.apache.pdfbox.pdmodel.font.Standard14Fonts;

public class GeneradorFacturaPDF {

    public static File generarFacturaPDF(Factura factura, Cliente cliente, String numeroFactura) throws IOException {
        PDDocument doc = new PDDocument();
        PDPage page = new PDPage(PDRectangle.LETTER);
        doc.addPage(page);

        PDFont font = new PDType1Font(Standard14Fonts.FontName.HELVETICA);

        PDPageContentStream cs = new PDPageContentStream(doc, page);
        cs.beginText();
        cs.setFont(font, 12);
        cs.setLeading(14.5f);
        cs.newLineAtOffset(50, 700);

        cs.showText("FACTURA N°" + numeroFactura + " GENERADA");
        cs.newLine();
        cs.newLine();
        cs.showText("==========DATOS DEL CLIENTE==========");
        cs.newLine();
        cs.newLine();
        cs.showText("Documento: " + cliente.getDocumento());
        cs.newLine();
        cs.showText("Nombre: " + cliente.getNombre() + " " + cliente.getApellido());
        cs.newLine();
        cs.showText("Teléfono: " + cliente.getTelefono());
        cs.newLine();
        cs.showText("Correo: " + cliente.getCorreo());
        cs.newLine();
        cs.showText("Dirección: " + cliente.getDireccion());
        cs.newLine();
        cs.newLine();
        cs.showText("=========DATOS DE LA FACTURA=========");
        cs.newLine();
        cs.newLine();
        cs.showText("Fecha: " + LocalDate.now().toString());
        cs.newLine();
        cs.newLine();
        cs.showText("PRODUCTOS:");
        cs.newLine();
        cs.newLine();

        for (Producto p : factura.getProductosAgregados()) {
            String linea = p.getNombre() + " x" + p.getStock() + " - $" + p.getPrecio();
            cs.showText(linea);
            cs.newLine();
        }

        cs.newLine();
        cs.showText("Subtotal: $" + factura.getSubtotal());
        cs.newLine();
        cs.showText("IVA: $" + factura.getIva());
        cs.newLine();
        cs.showText("Total: $" + factura.getTotal());

        cs.newLine();
        cs.newLine();
        cs.showText("¡GRACIAS POR SU COMPRA!");

        cs.endText();
        cs.close();

        File tempFile = File.createTempFile("factura_", ".pdf");
        doc.save(tempFile);
        doc.close();

        return tempFile;
    }
}


/*  COMO USAR
try {
    File pdf = GeneradorFacturaPDF.generarFacturaPDF(factura);
    new VistaFacturaPDF(pdf);
} catch (IOException ex) {
    JOptionPane.showMessageDialog(null, "Error generando factura: " + ex.getMessage());
}
 */
