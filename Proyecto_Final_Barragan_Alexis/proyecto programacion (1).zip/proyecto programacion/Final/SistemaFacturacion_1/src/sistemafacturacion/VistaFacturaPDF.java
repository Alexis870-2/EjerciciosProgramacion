package sistemafacturacion;

import javax.print.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.io.File;
import java.io.FileInputStream;

public class VistaFacturaPDF extends JFrame {

    private JComboBox<PrintService> impresoraComboBox;
    private JButton imprimirBtn;

    public VistaFacturaPDF(File archivoPDF) {
        setTitle("Generación de Factura");
        setSize(600, 700);
        setLayout(new BorderLayout());

        // Panel de botones
        JPanel panelTop = new JPanel();
        impresoraComboBox = new JComboBox<>(PrintServiceLookup.lookupPrintServices(null, null));
        imprimirBtn = new JButton("Imprimir");

        panelTop.add(new JLabel("Impresora:"));
        panelTop.add(impresoraComboBox);
        panelTop.add(imprimirBtn);
        add(panelTop, BorderLayout.NORTH);

        // Preview del PDF (abriendo el archivo con el visor del sistema operativo)
        JTextArea preview = new JTextArea("Factura generada en: \n" + archivoPDF.getAbsolutePath()
                + "\n\n(Se abrirá automáticamente en el visor predeterminado)");
        preview.setEditable(false);
        add(new JScrollPane(preview), BorderLayout.CENTER);

        // Abrir el PDF en el visor predeterminado del sistema
        try {
            Desktop.getDesktop().open(archivoPDF);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "No se pudo abrir el PDF: " + ex.getMessage());
        }

        // Acción imprimir
        imprimirBtn.addActionListener((ActionEvent e) -> {
            PrintService impresoraSeleccionada = (PrintService) impresoraComboBox.getSelectedItem();
            try {
                DocPrintJob job = impresoraSeleccionada.createPrintJob();
                Doc doc = new SimpleDoc(new FileInputStream(archivoPDF), DocFlavor.INPUT_STREAM.AUTOSENSE, null);
                job.print(doc, null);
                JOptionPane.showMessageDialog(this, "Factura enviada a la impresora.");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Error al imprimir: " + ex.getMessage());
            }
        });

        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setVisible(true);
    }
}
