public class ecuacion2grado {

}
