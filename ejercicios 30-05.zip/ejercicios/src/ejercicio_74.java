public class ejercicio_74 {

}
