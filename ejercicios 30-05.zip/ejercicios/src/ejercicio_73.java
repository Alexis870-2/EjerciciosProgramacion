public class ejercicio_73 {

}
