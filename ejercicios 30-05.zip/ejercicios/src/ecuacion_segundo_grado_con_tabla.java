public class ecuacion_segundo_grado_con_tabla {

}
