public class ejercicio_72 {

}
