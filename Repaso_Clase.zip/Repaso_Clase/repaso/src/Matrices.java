public class Matrices {
    public static void main(String[] args) {
        double[][] matrix = new double[][]{
            {18, 7, 0},
            {20, 9, 0},
            {24, 8, 0},
            {17, 5, 0},
            {26, 11, 0}
        };
        //Cajcular la temperatura
}
public static void CalcularTemperaturaMeida(double[][] _matriz) {
    for (int f = 0; f < _matriz.length; f++) {
      _matriz[f][2]  ,
    }
    
}
public static void ImprimirMatrizTemperatura(String[] args) {
    
}
}
