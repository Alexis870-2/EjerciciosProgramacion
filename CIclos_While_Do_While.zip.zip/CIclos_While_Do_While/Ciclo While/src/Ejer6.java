import java.util.Scanner;

public class Ejer6 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Ingreso de los dos números
        System.out.print("Ingrese el primer número: ");
        int a = scanner.nextInt();

        System.out.print("Ingrese el segundo número: ");
        int b = scanner.nextInt();

        // Método de Euclides para el cálculo del MCD
        int mcd = calcularMCD(a, b);

        // Mostrar el resultado
        System.out.println("El MCD de " + a + " y " + b + " es: " + mcd);

        scanner.close();
    }

    // Método para calcular el MCD usando el algoritmo de Euclides
    public static int calcularMCD(int a, int b) {
        // Asegurarse de que los números sean positivos
        a = Math.abs(a);
        b = Math.abs(b);

        // Aplicando el algoritmo de Euclides (divisiones sucesivas)
        while (b != 0) {
            int temp = b;
            b = a % b;
            a = temp;
        }

        return a;
    }
}

