/*Solicitar dos numeros 
 * realizar la suma, resta, multiplicacion,division,sacar residuo
 * 
 */

import Clases.Triangulo;

public class Parame_la_mano {
    public int num1, num2;
    

    public void suma(){
        double resultado =0;
        resultado= Math.pow (num1,num2);
        System.out.println("El resultado de la suma es:"+resultado);
    }
     public void resta(){
        double resultado =0;
        resultado=(num1-num2);
        System.out.println("El resultado de la resta es:"+resultado);
    }
     public void multiplicacion(){
        double resultado =0;
        resultado= (num1*num2);
        System.out.println("El resultado de la multiplicacion  es:"+resultado);
    }
     public void division(){
        double resultado =0;
        resultado = (num1/num2);
        System.out.println("El resultado de la division es:"+resultado);
    }
     public void residuo(){
        double resultado =0;
        resultado= (num1%num2);
        System.out.println("El resultado del residuo es:"+resultado);
    }

    public static void main(String[] args) {
        Parame_la_mano respu = new Parame_la_mano();
        respu.suma();
        respu.resta();
        respu.multiplicacion();
        respu.division();
        respu.residuo();
    }
}
