package Clases;

import java.util.Scanner;

/* Solicitar los 3 lados del triangulo
 * visualizar los datos ingresados
 * imprimir el lado mas grande
 * Si el triangulo es equilatero
 */
public class Triangulo {
    private int lado1,lado2,lado3;
    private Scanner teclado;

    public void Inicializar(){
        Scanner teclado=new Scanner(System.in);
        System.out.println("Ingrese el lado 1: ");
        lado1=teclado.nextInt();
        System.out.println("Ingrese el lado 2: ");
        lado2=teclado.nextInt();
        System.out.println("Ingrese el lado 3: ");
        lado3=teclado.nextInt();
    }

    public void ImprimirLadosTriangulo(){
        System.out.println("Lado 1: "+lado1);
        System.out.println("Lado 2: "+lado2);
        System.out.println("Lado 3: "+lado3);
    }

    public void ImprimirLadoMasGrande(){
        System.out.print("El lado más grande es: ");
        if (lado1>lado2 && lado1>lado3) {
            System.out.println(lado1);
        } else {
           if (lado2>lado3) {
            System.out.println(lado2);
           } else{
            System.out.println(lado3);
           }
        }
    }

    public void ValidarSiEsEquilatero(){
        if (lado1==lado2 && lado2==lado3) {
            System.out.println("El triangulo es equilatero");
        }else{
            System.out.println("El triangulo no es equilatero");
        }
    }


    public static void main(String[] args) {
        Triangulo triangulo_1 = new Triangulo();
        triangulo_1.Inicializar();
        triangulo_1.ImprimirLadosTriangulo();
        triangulo_1.ImprimirLadoMasGrande();
        triangulo_1.ValidarSiEsEquilatero();
    }
}