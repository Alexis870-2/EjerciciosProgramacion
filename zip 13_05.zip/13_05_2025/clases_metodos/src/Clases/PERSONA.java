package Clases;

import java.beans.PersistenceDelegate;
import java.nio.channels.Pipe.SourceChannel;
import java.util.Scanner;

public class PERSONA {
    private String nombre;
    private int edad;
     private Scanner teclado;

    public void InicializarVariables(){
        teclado=new Scanner(System.in);
        System.out.println("Ingrese el nombre: ");
        nombre=teclado.next();
        System.out.println("Ingrese su edad: ");
        edad=teclado.nextInt();
    }

    public void ImprimirInformacio(){
        System.out.println("Nombre: "+nombre);
        System.out.println("Edad: "+edad);
    }

    private void ImprimirSiEsMayorEdad(){
        if(edad>=18){
            System.out.println(nombre+" Es mayor de Edad");
        }else{
            System.out.println(nombre+" NO es mayor de edad");
        }
    }


    public void LeerMasDatos(){
        teclado=new Scanner(System.in);
    }

    public static void main(String[] args) {
        //crear una INSTANCIA de la clase PERSONA
        PERSONA persona_1=new PERSONA();
        //Leer los datos de la persona a través de metodo InicializarVariables()
        persona_1.InicializarVariables();
        //Imprimir los datos de la persona
        persona_1.ImprimirInformacio();
        //Imprimir si es mayor de edad
        persona_1.ImprimirSiEsMayorEdad();
    }
}


