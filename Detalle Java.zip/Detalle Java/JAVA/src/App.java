import java.util.LinkedList;
import java.util.List;

import org.w3c.dom.views.DocumentView;

public class App {
    public static void main(String[] args) throws Exception {
        System.out.println("Hello, World!");
        
        LinkedList<DetalleVenta> listaDV = new LinkedList<>();
        listaDV.add(new  DetalleVenta("monitor", 96, 1, 96));
        listaDV.add(new DetalleVenta("mouse wifi", 20, 1, 20));
        System.out.println(DevolverHtmlComprobante(listaDV));
    }
   
    public static String DevolverHtmlComprobante(LinkedList<DetalleVenta> lista){

        String resultado= "";
        resultado+= "<html>";
        resultado+="<head>";
        resultado+=" <meta charset=\"UTF_8\">";
        resultado+="</head>";

        resultado+="<body>";

        resultado="<table>";
        resultado+="<tr> <td>Producto</td>     <td>Precio</td>  <td>Cantidad</td>  <td>Subtotal</td>  </tr>";

        for (DetalleVenta dv : lista) {
            resultado+="<td> <td>"+ dv.getProducto()+
            "td> <td>"+dv.getPreecio()+
            "td> <td>"+dv.getCantidad()+
            "td> <td>"+dv.getSubtotal()+"td> <td>";
            
        }
        resultado+="</table>";
        resultado+="<body>";
        resultado+= "<html>";
        return resultado;
    

    
}
}