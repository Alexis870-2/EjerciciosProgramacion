public class DetalleVenta {
    private String producto ;
    private double preecio;
    private int cantidad;
    private String Subtotal ;

    public DetalleVenta(String producto, double preecio, int cantidad, int subtotal) {
        this.producto = producto;
        this.preecio = preecio;
        this.cantidad = cantidad;
        Subtotal = Subtotal;
    }
    public String getProducto() {
        return producto;
    }
    public void setProducto(String producto) {
        this.producto = producto;
    }
    public double getPreecio() {
        return preecio;
    }
    public void setPreecio(double preecio) {
        this.preecio = preecio;
    }
    public int getCantidad() {
        return cantidad;
    }
    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }
    public String getSubtotal() {
        return Subtotal;
    }
    public void setSubtotal(String subtotal) {
        Subtotal = subtotal;
    }






}