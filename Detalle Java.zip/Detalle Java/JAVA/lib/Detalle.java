public class Detalle {
    private String producto;
    private String precio;
    private int;
    private String;

}
