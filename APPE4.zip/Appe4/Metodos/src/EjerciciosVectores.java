import java.util.*;

public class EjerciciosVectores {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        ejercicio1(sc);
        ejercicio2(sc);
        ejercicio3(sc);
        ejercicio4(sc);
        ejercicio5(sc);
        ejercicio6();
        ejercicio7(sc);
        ejercicio8(sc);
        ejercicio9();
        ejercicio10(sc);
        ejercicio11(sc);
        ejercicio12(sc);
        ejercicio13(sc);
    }

    // 1. Suma y promedio de 4 números
    public static void ejercicio1(Scanner sc) {
        int[] numeros = new int[4];
        int suma = 0;
        System.out.println("Ejercicio 1:");
        for (int i = 0; i < 4; i++) {
            System.out.print("Ingrese número " + (i + 1) + ": ");
            numeros[i] = sc.nextInt();
            suma += numeros[i];
        }
        double promedio = (double) suma / 4;
        System.out.println("Suma: " + suma + ", Promedio: " + promedio);
    }

    // 2. Múltiplos de n en 6 números
    public static void ejercicio2(Scanner sc) {
        int[] numeros = new int[6];
        System.out.println("\nEjercicio 2:");
        System.out.print("Ingrese el número n: ");
        int n = sc.nextInt();
        int contador = 0;
        for (int i = 0; i < 6; i++) {
            System.out.print("Número " + (i + 1) + ": ");
            numeros[i] = sc.nextInt();
            if (numeros[i] % n == 0) contador++;
        }
        System.out.println("Cantidad de múltiplos de " + n + ": " + contador);
    }

    // 3. Ordenar 5 números ascendente o descendente
    public static void ejercicio3(Scanner sc) {
        int[] numeros = new int[5];
        System.out.println("\nEjercicio 3:");
        for (int i = 0; i < 5; i++) {
            System.out.print("Número " + (i + 1) + ": ");
            numeros[i] = sc.nextInt();
        }
        System.out.print("Orden (A = ascendente, D = descendente): ");
        char orden = sc.next().toUpperCase().charAt(0);
        Arrays.sort(numeros);
        System.out.println("Números ordenados:");
        if (orden == 'A') {
            for (int num : numeros) System.out.print(num + " ");
        } else {
            for (int i = numeros.length - 1; i >= 0; i--) System.out.print(numeros[i] + " ");
        }
        System.out.println();
    }

    // 4. Números repetidos en 6 ingresados
    public static void ejercicio4(Scanner sc) {
        System.out.println("\nEjercicio 4:");
        int[] numeros = new int[6];
        for (int i = 0; i < 6; i++) {
            System.out.print("Número " + (i + 1) + ": ");
            numeros[i] = sc.nextInt();
        }
        Set<Integer> unicos = new HashSet<>();
        Set<Integer> repetidos = new HashSet<>();
        for (int num : numeros) {
            if (!unicos.add(num)) repetidos.add(num);
        }
        System.out.println("Cantidad de números repetidos: " + repetidos.size());
    }

    // 5. 10 primos posteriores a n
    public static void ejercicio5(Scanner sc) {
        System.out.println("\nEjercicio 5:");
        System.out.print("Ingrese un número n: ");
        int n = sc.nextInt();
        int[] primos = new int[10];
        int count = 0, num = n + 1;
        while (count < 10) {
            if (esPrimo(num)) primos[count++] = num;
            num++;
        }
        int suma = Arrays.stream(primos).sum();
        double promedio = suma / 10.0;
        System.out.println("10 números primos siguientes:");
        System.out.println(Arrays.toString(primos));
        System.out.println("Suma: " + suma + ", Promedio: " + promedio);
    }

    public static boolean esPrimo(int num) {
        if (num < 2) return false;
        for (int i = 2; i <= Math.sqrt(num); i++)
            if (num % i == 0) return false;
        return true;
    }

    // 6. Insertar Opel y Citroen en array ordenado
    public static void ejercicio6() {
        System.out.println("\nEjercicio 6:");
        String[] coches = {"Audi", "BMW", "Chevrolet", "Fiat", "Kia", "Toyota"};
        List<String> lista = new ArrayList<>(Arrays.asList(coches));
        lista.add("Opel");
        lista.add("Citroen");
        Collections.sort(lista);
        System.out.println("Coches actualizados:");
        System.out.println(lista);
    }

    // 7. Copiar vector de 5 cadenas en orden inverso
    public static void ejercicio7(Scanner sc) {
        System.out.println("\nEjercicio 7:");
        String[] original = new String[5];
        String[] inverso = new String[5];
        for (int i = 0; i < 5; i++) {
            System.out.print("Palabra " + (i + 1) + ": ");
            original[i] = sc.next();
        }
        for (int i = 0; i < 5; i++) {
            inverso[i] = original[4 - i];
        }
        System.out.println("Vector invertido:");
        System.out.println(Arrays.toString(inverso));
    }

    // 8. Notas de un alumno
    public static void ejercicio8(Scanner sc) {
        System.out.println("\nEjercicio 8:");
        double[] notas = new double[5];
        for (int i = 0; i < 5; i++) {
            double nota;
            do {
                System.out.print("Nota " + (i + 1) + " (0-10): ");
                nota = sc.nextDouble();
            } while (nota < 0 || nota > 10);
            notas[i] = nota;
        }
        double promedio = Arrays.stream(notas).average().orElse(0);
        double max = Arrays.stream(notas).max().orElse(0);
        double min = Arrays.stream(notas).min().orElse(0);
        System.out.println("Notas: " + Arrays.toString(notas));
        System.out.println("Media: " + promedio + ", Máxima: " + max + ", Mínima: " + min);
    }

    // 9. Vector aleatorio ordenado
    public static void ejercicio9() {
        System.out.println("\nEjercicio 9:");
        int[] aleatorio = new int[10];
        Random rand = new Random();
        for (int i = 0; i < aleatorio.length; i++) aleatorio[i] = rand.nextInt(100);
        Arrays.sort(aleatorio);
        System.out.println("Vector ordenado: " + Arrays.toString(aleatorio));
    }

    // 10. vector3 = vector1 + vector2
    public static void ejercicio10(Scanner sc) {
        System.out.println("\nEjercicio 10:");
        int[] v1 = new int[5], v2 = new int[5], v3 = new int[5];
        for (int i = 0; i < 5; i++) {
            System.out.print("Vector1[" + i + "]: ");
            v1[i] = sc.nextInt();
        }
        for (int i = 0; i < 5; i++) {
            System.out.print("Vector2[" + i + "]: ");
            v2[i] = sc.nextInt();
            v3[i] = v1[i] + v2[i];
        }
        System.out.println("Vector3 (suma): " + Arrays.toString(v3));
    }

    // 11. Alumnos mayores de edad y promedio menores
    public static void ejercicio11(Scanner sc) {
        System.out.println("\nEjercicio 11:");
        List<String> mayores = new ArrayList<>();
        List<Integer> menores = new ArrayList<>();
        while (true) {
            System.out.print("Nombre del alumno (* para terminar): ");
            String nombre = sc.next();
            if (nombre.equals("*")) break;
            System.out.print("Edad: ");
            int edad = sc.nextInt();
            if (edad >= 18) mayores.add(nombre);
            else menores.add(edad);
        }
        System.out.println("Alumnos mayores de edad: " + mayores);
        if (!menores.isEmpty()) {
            double prom = menores.stream().mapToInt(Integer::intValue).average().orElse(0);
            System.out.println("Promedio edad de menores: " + prom);
        }
    }

    // 12. Repetición del 11 (solo mayores)
    public static void ejercicio12(Scanner sc) {
        System.out.println("\nEjercicio 12:");
        List<String> mayores = new ArrayList<>();
        while (true) {
            System.out.print("Nombre del alumno (* para terminar): ");
            String nombre = sc.next();
            if (nombre.equals("*")) break;
            System.out.print("Edad: ");
            int edad = sc.nextInt();
            if (edad >= 18) mayores.add(nombre);
        }
        System.out.println("Alumnos mayores de edad: " + mayores);
    }

    // 13. Temperatura mínima y máxima de 5 días
    public static void ejercicio13(Scanner sc) {
        System.out.println("\nEjercicio 13:");
        double[][] temperaturas = new double[5][2];
        double[] medias = new double[5];
        for (int i = 0; i < 5; i++) {
            System.out.print("Día " + (i + 1) + " - Temp mínima: ");
            temperaturas[i][0] = sc.nextDouble();
            System.out.print("Día " + (i + 1) + " - Temp máxima: ");
            temperaturas[i][1] = sc.nextDouble();
            medias[i] = (temperaturas[i][0] + temperaturas[i][1]) / 2;
        }
        double minMedia = medias[0], maxMedia = medias[0];
        int diaMin = 1, diaMax = 1;
        for (int i = 1; i < medias.length; i++) {
            if (medias[i] < minMedia) {
                minMedia = medias[i];
                diaMin = i + 1;
            }
            if (medias[i] > maxMedia) {
                maxMedia = medias[i];
                diaMax = i + 1;
            }
        }
        System.out.println("Promedios diarios: " + Arrays.toString(medias));
        System.out.println("Día con menor promedio: Día " + diaMin);
        System.out.println("Día con mayor promedio: Día " + diaMax);
    }
}

