public class Vehiculo {
    String marca;
    String modelo;
    int año;
    double Precio;
    String color;

    public void ImprimirInformacionVehiculo() {
        System.out.println("-------------------------------");
        System.out.println(" Atributo      | Valor");
        System.out.println("-------------------------------");
        System.out.println(" Marca         | " + marca);
        System.out.println(" Modelo        | " + modelo);
        System.out.println(" Año           | " + año);
        System.out.println(" Precio base   | $" + Precio);
        System.out.println(" Color         | " + color);
        System.out.println("-------------------------------");
    }

    public void ImprimirDatosVehiculo(String marca_, String modelo_, int año_, String color_, double Precio_) {
        marca = marca_;
        modelo = modelo_;
        año = año_;
        color = color_;
        Precio = Precio_;
    }

    // Método que calcula la ganancia con porcentaje fijo 15%
    public double CalcularGanancia() {
        double porcentaje = 15; // Ganancia fija del 15%

        double ganancia = (Precio * porcentaje) / 100;
        double precioFinal = Precio + ganancia;

        System.out.println(">>> El vendedor ganará el " + porcentaje + "% del precio base.");
        System.out.println(">>> Ganancia del vendedor: $" + ganancia);
        System.out.println(">>> Precio al público:     $" + precioFinal);
        System.out.println("-------------------------------");

        return ganancia;
    }

    public static void main(String[] args) {
        double gananciaTotal = 0; // Acumulador de ganancias

        Vehiculo vehiculo_1 = new Vehiculo();
        vehiculo_1.marca = "Kia";
        vehiculo_1.modelo = "Cerato";
        vehiculo_1.año = 2016;
        vehiculo_1.color = "Negro";
        vehiculo_1.Precio = 12000;
        vehiculo_1.ImprimirInformacionVehiculo();
        gananciaTotal += vehiculo_1.CalcularGanancia();

        Vehiculo vehiculo_2 = new Vehiculo();
        vehiculo_2.ImprimirDatosVehiculo("Ferrari", "Depredador", 2024, "Rojo", 19000);
        vehiculo_2.ImprimirInformacionVehiculo();
        gananciaTotal += vehiculo_2.CalcularGanancia();

        Vehiculo vehiculo_3 = new Vehiculo();
        vehiculo_3.ImprimirDatosVehiculo("Toyota", "Corolla", 2023, "Negro", 17500);
        vehiculo_3.ImprimirInformacionVehiculo();
        gananciaTotal += vehiculo_3.CalcularGanancia();

        // Mostrar la suma total de las ganancias
        System.out.println("=======================================");
        System.out.println(" TOTAL DE GANANCIAS DEL VENDEDOR: $" + gananciaTotal);
        System.out.println("=======================================");
    }
}
