public class Persona {

}
