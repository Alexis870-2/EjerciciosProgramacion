import java.util.Scanner;

public class Estudio {
    //Atributos
    String materia="FP";
    int tiempo=60;

    public void ImprimirInformacion(){
        System.out.println("Meria = "+ materia + " Tiempo = " + tiempo + "minutos");
    }

    public void ActualizarInformacion(String _materia, int _tiempo){
        materia = _materia;
        tiempo = _tiempo;
    }
     
    public void IngresarAtributos (){
        Scanner sc =new Scanner (System.in);
        System.out.println("Ingrese la materia");
        materia =sc.next();
         System.out.println("Ingrese  el tiempo");
        tiempo = sc.nextInt();
    }


    public static void main(String[] args) throws Exception {
        Estudio estudio = new Estudio();
        estudio.materia="Fundamentos de Programacion";
        estudio.tiempo=90;
        estudio.ImprimirInformacion();

        estudio.ActualizarInformacion("Fisica",   30);
        estudio.ImprimirInformacion();


        estudio.IngresarAtributos ();
        estudio.ImprimirInformacion();


    }
}