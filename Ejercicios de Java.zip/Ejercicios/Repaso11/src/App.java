import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {
        System.out.println("Hello, World!");
        // Crear un objeto Scanner para leer datos desde la entrada estándar
        Scanner scanner = new Scanner(System.in);

        // Pedir el monto de compra
        System.out.print("Introduce el monto de compra: $");
        double montoCompra = scanner.nextDouble();

        double montoFinal;

        // Aplicar descuento según el monto de compra
        if (montoCompra >= 500) {
            // Descuento del 20% si el monto es mayor o igual a 500
            montoFinal = montoCompra * 0.80;
        } else if (montoCompra >= 100) {
            // Descuento del 10% si el monto es mayor o igual a 100 pero menor a 500
            montoFinal = montoCompra * 0.90;
        } else {
            // Si el monto es menor a 100, no se aplica descuento
            montoFinal = montoCompra;
        }

        // Mostrar el monto final a pagar
        System.out.println("El monto final a pagar es: $" + montoFinal);

        // Cerrar el scanner
        scanner.close();
    }
}
