import java.util.Scanner;
public class App {
    public static void main(String[] args) throws Exception {
        System.out.println("Hello, World!");
        Scanner scanner = new Scanner(System.in);
        
            System.out.print("Ingrese el grado: ");
            double grado = scanner.nextDouble();
        
            if (grado >= 90) {
              System.out.println("La calificación es: A");
            } else if (grado >= 80) {
              System.out.println("La calificación es: B");
            } else if (grado >= 70) {
              System.out.println("La calificación es: C");
            } else if (grado >= 69) {
              System.out.println("La calificación es: D");
            } else {
              System.out.println("La calificación es: F");
            }
        
            scanner.close();
         
        
        
    }
}
