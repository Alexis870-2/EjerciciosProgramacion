import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {
        System.out.println("Hello, World!");
        // Crear un objeto Scanner para leer datos desde la entrada estándar
        Scanner scanner = new Scanner(System.in);
        
        // Pedir los tres números al usuario
        System.out.print("Introduce el primer número: ");
        int num1 = scanner.nextInt();
        
        System.out.print("Introduce el segundo número: ");
        int num2 = scanner.nextInt();
        
        System.out.print("Introduce el tercer número: ");
        int num3 = scanner.nextInt();
        
        // Verificar si los números están en orden ascendente
        if (num1 < num2 && num2 < num3) {
            System.out.println("Los números están en orden ascendente.");
        }
        // Verificar si los números están en orden descendente
        else if (num1 > num2 && num2 > num3) {
            System.out.println("Los números están en orden descendente.");
        }
        // Si no están ni en orden ascendente ni descendente
        else {
            System.out.println("Los números no están en orden numérico.");
        }
        
        // Cerrar el scanner
        scanner.close();
    }
}
