import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {
        System.out.println("Hello, World!");
         Scanner scanner = new Scanner(System.in);

        // Solicitar al usuario el número
        System.out.print("Ingrese un número: ");
        double numero = scanner.nextDouble();

        // Verificar si el número es negativo
        if (numero < 0) {
            System.out.println("No se puede calcular la raíz cuadrada de un número negativo en los números reales.");
        } else {
            // Calcular la raíz cuadrada
            double raiz = Math.sqrt(numero);
            System.out.println("La raíz cuadrada de " + numero + " es: " + raiz);
        }

        // Cerrar el scanner
        scanner.close();
    }
}
