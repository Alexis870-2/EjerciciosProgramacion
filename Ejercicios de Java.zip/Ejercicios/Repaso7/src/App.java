import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {
        System.out.println("Hello, World!");
        // Crear un objeto Scanner para leer datos desde la entrada estándar
        Scanner scanner = new Scanner(System.in);
        
        // Pedir los dos números al usuario
        System.out.print("Introduce el primer número: ");
        double num1 = scanner.nextDouble();
        
        System.out.print("Introduce el segundo número: ");
        double num2 = scanner.nextDouble();
        
        // Pedir la selección de la operación
        System.out.println("Selecciona la operación aritmética: ");
        System.out.println("1 - Sumar");
        System.out.println("2 - Restar");
        System.out.println("3 - Multiplicar");
        System.out.println("4 - Dividir");
        System.out.print("Introduce el número correspondiente a la operación: ");
        int seleccionOp = scanner.nextInt();
        
        double resultado;
        
        // Usar una estructura switch para decidir la operación a realizar
        switch (seleccionOp) {
            case 1:
                resultado = num1 + num2;
                System.out.println("El resultado de la suma es: " + resultado);
                break;
            case 2:
                resultado = num1 - num2;
                System.out.println("El resultado de la resta es: " + resultado);
                break;
            case 3:
                resultado = num1 * num2;
                System.out.println("El resultado de la multiplicación es: " + resultado);
                break;
            case 4:
                if (num2 != 0) {
                    resultado = num1 / num2;
                    System.out.println("El resultado de la división es: " + resultado);
                } else {
                    System.out.println("Error: No se puede dividir entre cero.");
                }
                break;
            default:
                System.out.println("Opción no válida. Selecciona un número entre 1 y 4.");
        }
        
        // Cerrar el scanner
        scanner.close();
    }
}
