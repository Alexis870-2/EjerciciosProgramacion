import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {
        System.out.println("Hello, World!");
        // Crear un objeto Scanner para leer datos desde la entrada estándar
        Scanner scanner = new Scanner(System.in);

        // Leer la fecha de nacimiento
        System.out.print("Introduce el día de nacimiento: ");
        int diaNacimiento = scanner.nextInt();
        
        System.out.print("Introduce el mes de nacimiento: ");
        int mesNacimiento = scanner.nextInt();
        
        System.out.print("Introduce el año de nacimiento: ");
        int anioNacimiento = scanner.nextInt();

        // Leer la fecha actual
        System.out.print("Introduce el día actual: ");
        int diaActual = scanner.nextInt();
        
        System.out.print("Introduce el mes actual: ");
        int mesActual = scanner.nextInt();
        
        System.out.print("Introduce el año actual: ");
        int anioActual = scanner.nextInt();
        
        // Variables para calcular la edad
        int edadAnios = anioActual - anioNacimiento;
        int edadMeses = mesActual - mesNacimiento;
        int edadDias = diaActual - diaNacimiento;

        // Verificar si la fecha actual es anterior al cumpleaños de este año
        if (edadMeses < 0) {
            edadMeses += 12;
            edadAnios--;
        }

        if (edadDias < 0) {
            // Ajustar el número de días en el mes anterior
            // Consideramos la cantidad de días en el mes anterior
            int diasMesAnterior;
            if (mesActual == 1) {  // Enero
                diasMesAnterior = 31;  // Diciembre tiene 31 días
            } else if (mesActual == 3 || mesActual == 5 || mesActual == 7 || mesActual == 8 || mesActual == 10 || mesActual == 12) {
                diasMesAnterior = 31;
            } else if (mesActual == 4 || mesActual == 6 || mesActual == 9 || mesActual == 11) {
                diasMesAnterior = 30;
            } else {  // Febrero
                if ((anioActual % 4 == 0 && anioActual % 100 != 0) || (anioActual % 400 == 0)) {
                    diasMesAnterior = 29;  // Año bisiesto
                } else {
                    diasMesAnterior = 28;  // Año no bisiesto
                }
            }
            edadDias += diasMesAnterior;
            edadMeses--;
        }

        // Si el individuo tiene menos de un año
        if (edadAnios == 0) {
            System.out.println("La edad es de: " + edadMeses + " meses y " + edadDias + " días.");
        } else {
            System.out.println("La edad es de: " + edadAnios + " años.");
        }

        // Cerrar el scanner
        scanner.close();
    }
}
