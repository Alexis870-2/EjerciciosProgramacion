import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {
        System.out.println("Hello, World!");
        // Crear un objeto Scanner para leer datos desde la entrada estándar
        Scanner scanner = new Scanner(System.in);

        // Pedir los tres lados del triángulo
        System.out.print("Introduce el primer lado: ");
        double lado1 = scanner.nextDouble();
        
        System.out.print("Introduce el segundo lado: ");
        double lado2 = scanner.nextDouble();
        
        System.out.print("Introduce el tercer lado: ");
        double lado3 = scanner.nextDouble();

        // Verificar la desigualdad triangular
        if (lado1 + lado2 > lado3 && lado1 + lado3 > lado2 && lado2 + lado3 > lado1) {
            // Clasificar el triángulo según sus lados
            if (lado1 == lado2 && lado2 == lado3) {
                System.out.println("El triángulo es equilátero.");
            } else if (lado1 == lado2 || lado1 == lado3 || lado2 == lado3) {
                System.out.println("El triángulo es isósceles.");
            } else {
                System.out.println("El triángulo es escaleno.");
            }
        } else {
            System.out.println("El triángulo es inválido (no cumple la desigualdad triangular).");
        }

        // Cerrar el scanner
        scanner.close();
    }
}
