import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {
        System.out.println("Hello, World!");
        // Crear un scanner para recibir la entrada del usuario
        Scanner scanner = new Scanner(System.in);
        
        // Pedir la fecha al usuario en formato "día/mes/año"
        System.out.println("Introduce la fecha en formato DD/MM/YYYY:");
        String fechaInput = scanner.nextLine();
        
        // Crear un formateador de fecha
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        
        try {
            // Convertir la cadena de texto en un objeto LocalDate
            LocalDate fecha = LocalDate.parse(fechaInput, formatter);
            
            // Obtener la fecha del siguiente día
            LocalDate siguienteDia = fecha.plusDays(1);
            
            // Mostrar la fecha del siguiente día
            System.out.println("La fecha del día siguiente es: " + siguienteDia.format(formatter));
        } catch (Exception e) {
            // Si la fecha no tiene un formato válido, mostrar un mensaje de error
            System.out.println("Formato de fecha incorrecto. Asegúrate de usar DD/MM/YYYY.");
        }
        
        scanner.close();

    }
}
