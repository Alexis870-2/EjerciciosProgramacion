import java.util.Scanner;

import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {
        // Crear un scanner para leer los números
       Scanner tecla = new Scanner(System.in);
        System.out.println("Numero central de tres numeros");

        // Solicitar al usuario los tres números
        System.out.print("Ingrese el primer número: ");
        int num1 = tecla.nextInt();
        System.out.print("Ingrese el segundo número: ");
        int num2 = tecla.nextInt();
        System.out.print("Ingrese el tercer número: ");
        int num3 = tecla.nextInt();

        // Determinar cuál es el número central
        if ((num1 > num2 && num1 < num3) || (num1 < num2 && num1 > num3)) {
            System.out.println("El número central es: " + num1);
        } else if ((num2 > num1 && num2 < num3) || (num2 < num1 && num2 > num3)) {
            System.out.println("El número central es: " + num2);
        } else {
            System.out.println("El número central es: " + num3);
        }

        // Cerrar el scanner
        tecla.close();
        

    }
}
