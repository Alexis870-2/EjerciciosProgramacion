import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {
        System.out.println("Hello, World!");
        // Crear un scanner para recibir la entrada del usuario
        Scanner scanner = new Scanner(System.in);
        
        // Pedir el primer número
        System.out.println("Introduce el primer número:");
        int num1 = scanner.nextInt();
        
        // Pedir el segundo número
        System.out.println("Introduce el segundo número:");
        int num2 = scanner.nextInt();
        
        // Verificar si uno es divisor del otro
        if (num1 != 0 && num2 != 0) {
            if (num1 % num2 == 0) {
                System.out.println(num1 + " es divisible por " + num2);
            } else if (num2 % num1 == 0) {
                System.out.println(num2 + " es divisible por " + num1);
            } else {
                System.out.println("Ninguno de los dos números es divisor del otro.");
            }
        } else {
            System.out.println("Los números deben ser distintos de cero.");
        }

        scanner.close();
    }
}
