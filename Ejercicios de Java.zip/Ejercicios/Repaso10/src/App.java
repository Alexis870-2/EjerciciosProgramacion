import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {
        System.out.println("Hello, World!");
        // Crear un objeto Scanner para leer datos desde la entrada estándar
        Scanner scanner = new Scanner(System.in);

        // Pedir los dos números
        System.out.print("Introduce el primer número: ");
        double num1 = scanner.nextDouble();

        System.out.print("Introduce el segundo número: ");
        double num2 = scanner.nextDouble();

        // Pedir la operación
        System.out.print("Introduce la operación (+, -, *, /): ");
        String operacion = scanner.next();

        double resultado;

        // Realizar la operación según la entrada del usuario
        switch (operacion) {
            case "+":
                resultado = num1 + num2;
                System.out.println("El resultado de la suma es: " + resultado);
                break;
            case "-":
                resultado = num1 - num2;
                System.out.println("El resultado de la resta es: " + resultado);
                break;
            case "*":
                resultado = num1 * num2;
                System.out.println("El resultado de la multiplicación es: " + resultado);
                break;
            case "/":
                // Verificar si se intenta dividir por cero
                if (num2 != 0) {
                    resultado = num1 / num2;
                    System.out.println("El resultado de la división es: " + resultado);
                } else {
                    System.out.println("Error: No se puede dividir entre cero.");
                }
                break;
            default:
                // Si la operación no es válida
                System.out.println("Error: Operación no válida.");
        }

        // Cerrar el scanner
        scanner.close();
    }
}
